Config = {}

-- Lootdrop Zeiten (Serverzeit)
Config.CommonDropTimes = {
    {hour = 2, minute = 0},  -- 02:00
    {hour = 8, minute = 0},  -- 08:00
    {hour = 14, minute = 0}, -- 14:00
    {hour = 20, minute = 0}  -- 20:00
}

Config.ExclusiveDropTimes = {
    {hour = 4, minute = 0},  -- 04:00
    {hour = 12, minute = 0}, -- 12:00
    {hour = 20, minute = 0}  -- 20:00
}

-- Lootdrop Einstellungen
Config.DropDuration = 15 * 60000 -- 15 Minuten in Millisekunden
Config.CollectionTime = 2 * 60000 -- 2 Minuten in Millisekunden
Config.InteractionDistance = 25.0 -- Distanz in Metern (10m größer)
Config.CombatZoneRadius = 84.0 -- Radius der Kampfzone in Metern (20% größer)
Config.RespawnTime = 15 -- Respawn-Zeit in Sekunden

-- Lootdrop Positionen (zufällige Auswahl)
Config.DropLocations = {
    {x = 98.1888, y = 6971.4736, z = 10.1695},
    {x = 546.1957, y = 3363.8904, z = 99.8713},
    {x = 2243.2341, y = 2056.0825, z = 129.6703},
    {x = 3695.0229, y = 4544.4595, z = 24.6959},
    {x = 1013.7745, y = -3170.6973, z = 5.9007},
    {x = -2515.0908, y = 753.9451, z = 301.1295},
    {x = 2511.3652, y = 4970.6606, z = 44.5391}
}

-- Respawn-Punkte für jeden Lootdrop
Config.RespawnPoints = {
    -- Lootdrop 1: 98.1888, 6971.4736, 10.1695
    [1] = {
        {x = 54.6771, y = 7033.9043, z = 10.7013},
        {x = 154.6486, y = 7019.4683, z = 3.5472},
        {x = 165.3566, y = 6938.2207, z = 14.9274},
        {x = 111.1875, y = 6897.8359, z = 22.7375}
    },
    -- Lootdrop 2: 546.1957, 3363.8904, 99.8713
    [2] = {
        {x = 516.9133, y = 3421.1375, z = 59.2700},
        {x = 613.1752, y = 3398.7664, z = 89.9442},
        {x = 606.9933, y = 3324.2961, z = 77.5114},
        {x = 485.8483, y = 3324.0605, z = 82.9578}
    },
    -- Lootdrop 3: 2243.2341, 2056.0825, 129.6703
    [3] = {
        {x = 2195.7898, y = 2035.5397, z = 115.0466},
        {x = 2179.8804, y = 2104.4180, z = 125.4517},
        {x = 2266.6387, y = 2124.9155, z = 97.2777},
        {x = 2315.0444, y = 2070.7356, z = 116.7526}
    },
    -- Lootdrop 4: 3695.0229, 4544.4595, 24.6959
    [4] = {
        {x = 3638.5571, y = 4593.1562, z = 21.4712},
        {x = 3727.9133, y = 4610.8584, z = 11.8131},
        {x = 3761.9436, y = 4526.2114, z = 7.3901},
        {x = 3627.2720, y = 4515.3276, z = 37.8727}
    },
    -- Lootdrop 5: 1013.7745, -3170.6973, 5.9007
    [5] = {
        {x = 1048.3459, y = -3101.9451, z = 5.9010},
        {x = 1000.2490, y = -3090.8914, z = 5.9010},
        {x = 938.5065, y = -3183.0229, z = 5.9008},
        {x = 1013.9778, y = -3251.2131, z = 5.8906}
    },
    -- Lootdrop 6: -2515.0908, 753.9451, 301.1295
    [6] = {
        {x = -2513.4573, y = 827.4627, z = 283.0868},
        {x = -2441.9148, y = 768.4853, z = 287.8074},
        {x = -2530.9978, y = 689.1653, z = 261.7431},
        {x = -2573.6572, y = 792.9890, z = 272.1410}
    },
    -- Lootdrop 7: 2511.3652, 4970.6606, 44.5391
    [7] = {
        {x = 2433.6807, y = 4982.8828, z = 46.0081},
        {x = 2547.7896, y = 5036.5928, z = 44.5060},
        {x = 2584.3840, y = 4962.0781, z = 40.3267},
        {x = 2444.6680, y = 4953.6045, z = 45.1326}
    }
}

-- Lootdrop Prop und Blip
Config.DropProp = 'prop_box_wood05a'
Config.BlipSprite = 478
Config.BlipColor = 5
Config.BlipScale = 1.0
Config.BlipName = 'Lootdrop'

-- Belohnungen (angepasst für Standard-ESX-Items)
Config.CommonRewards = {
    {name = 'fixkit', label = 'Reparaturkit', count = 5, chance = 25},
    {name = 'clip', label = 'Munition', count = 10, chance = 25},
    {name = 'bandage', label = 'Verband', count = 15, chance = 20},
    {name = 'money', label = 'Bargeld', count = 15000, chance = 30}
}

Config.ExclusiveRewards = {
    {name = 'weapon_pistol', label = 'Pistole', count = 1, chance = 40},
    {name = 'weapon_heavypistol', label = 'Schwere Pistole', count = 1, chance = 35},
    {name = 'black_money', label = 'Schwarzgeld', count = 25000, chance = 15}
    {name = 'weapon_pistol50 ', label = '50. Pistole', count = 1, chance = 10}
}

-- Benachrichtigungen
Config.Notifications = {
    participation = {type = "success", title = "Lootdrop", message = "Du nimmst am Lootdrop teil!", duration = 5000},
    stayClose = {type = "warning", title = "Lootdrop", message = "Bleibe in der Nähe um den Drop zu sichern!", duration = 5000},
    lost = {type = "error", title = "Lootdrop", message = "Du hast den Lootdrop verloren!", duration = 5000},
    help = {type = "info", title = "Hinweis", message = "Drücke E um den Lootdrop zu aktivieren", duration = 5000}
}

Config.Announcements = {
    landed = {title = "Lootdrop", message = "📦 Ein Lootdrop ist gelandet!", duration = 5000},
    collected = {title = "Lootdrop", message = "🎁 Der Lootdrop wurde erfolgreich eingesammelt!", duration = 5000},
    disappeared = {title = "Lootdrop", message = "❌ Der Lootdrop wurde nicht eingesammelt und ist verschwunden.", duration = 5000}
}