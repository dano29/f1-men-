-- ESX initialisieren
local ESX = nil
Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(0)
    end
end)
local currentDrop = nil
local dropBlip = nil
local dropObject = nil
local isCollecting = false
local collectionStartTime = 0
local collectionTimeLeft = 0
local inDropZone = false
local inCombatZone = false
local combatZoneBlip = nil
local isDead = false
local respawnTimer = 0

-- Funktion zum Erstellen eines Lootdrops
RegisterNetEvent('lootdrop:createDrop')
AddEventHandler('lootdrop:createDrop', function(dropData)
    currentDrop = dropData
    
    -- Erstelle Blip für den Lootdrop
    if dropBlip then RemoveBlip(dropBlip) end
    
    dropBlip = AddBlipForCoord(dropData.position.x, dropData.position.y, dropData.position.z)
    SetBlipSprite(dropBlip, Config.BlipSprite)
    SetBlipColour(dropBlip, Config.BlipColor)
    SetBlipScale(dropBlip, Config.BlipScale)
    SetBlipAsShortRange(dropBlip, false)
    
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(Config.BlipName)
    EndTextCommandSetBlipName(dropBlip)
    
    -- Erstelle Blip für die Kampfzone
    if combatZoneBlip then RemoveBlip(combatZoneBlip) end
    
    combatZoneBlip = AddBlipForRadius(dropData.position.x, dropData.position.y, dropData.position.z, Config.CombatZoneRadius)
    SetBlipColour(combatZoneBlip, 1) -- Rot
    SetBlipAlpha(combatZoneBlip, 128) -- Halbtransparent
    
    -- Entferne vorhandenes Prop, falls vorhanden
    if dropObject then
        DeleteObject(dropObject)
        dropObject = nil
    end
    
    -- Erstelle neues Prop
    RequestModel(GetHashKey(Config.DropProp))
    while not HasModelLoaded(GetHashKey(Config.DropProp)) do
        Citizen.Wait(1)
    end
    
    dropObject = CreateObject(GetHashKey(Config.DropProp), dropData.position.x, dropData.position.y, dropData.position.z - 1.0, true, true, true)
    PlaceObjectOnGroundProperly(dropObject)
    FreezeEntityPosition(dropObject, true)
    SetModelAsNoLongerNeeded(GetHashKey(Config.DropProp))
end)

-- Funktion zum Entfernen eines Lootdrops
RegisterNetEvent('lootdrop:removeDrop')
AddEventHandler('lootdrop:removeDrop', function()
    if dropBlip then
        RemoveBlip(dropBlip)
        dropBlip = nil
    end
    
    if combatZoneBlip then
        RemoveBlip(combatZoneBlip)
        combatZoneBlip = nil
    end
    
    if dropObject then
        DeleteObject(dropObject)
        dropObject = nil
    end
    
    currentDrop = nil
    isCollecting = false
    inDropZone = false
    inCombatZone = false
    
    -- Wenn der Spieler tot ist, setze isDead zurück, damit andere Skripte funktionieren können
    if isDead then
        TriggerEvent('chat:addMessage', {
            color = {255, 0, 0},
            multiline = true,
            args = {"LOOTDROP", "Automatischer Respawn deaktiviert - Lootdrop ist nicht mehr aktiv."}
        })
        isDead = false
    end
    
    -- UI ausblenden
    SendNUIMessage({
        action = 'hideUI'
    })
end)

-- Funktion zum Wiederherstellen der Kampffähigkeiten wurde entfernt und direkt in den Thread integriert

-- Funktion zum Starten des Sammelns
RegisterNetEvent('lootdrop:startCollection')
AddEventHandler('lootdrop:startCollection', function(collectionTime)
    isCollecting = true
    collectionStartTime = GetGameTimer()
    collectionTimeLeft = collectionTime
    
    -- Verwende die Unique Progressbar
    TriggerEvent('unique_progressbar', "LOOTDROP WIRD EINGESAMMELT", collectionTime)
    
    -- Timer-Thread
    Citizen.CreateThread(function()
        while isCollecting do
            Citizen.Wait(100)
            
            local currentTime = GetGameTimer()
            local elapsedTime = currentTime - collectionStartTime
            collectionTimeLeft = collectionTimeLeft - 100
            
            -- Überprüfe, ob die Zeit abgelaufen ist
            if collectionTimeLeft <= 0 then
                isCollecting = false
                TriggerServerEvent('lootdrop:completeCollection')
                break
            end
            
            -- Überprüfe, ob der Spieler noch in der Zone ist
            local playerPed = PlayerPedId()
            local playerCoords = GetEntityCoords(playerPed)
            local dropCoords = vector3(currentDrop.position.x, currentDrop.position.y, currentDrop.position.z)
            local distance = #(playerCoords - dropCoords)
            
            if distance > Config.InteractionDistance then
                isCollecting = false
                TriggerEvent('unique_progressbar:Stop') -- Stoppe die Progressbar
                TriggerServerEvent('lootdrop:leftArea')
                inDropZone = false
                break
            end
        end
    end)
end)

-- Funktion zum Stoppen des Sammelns
RegisterNetEvent('lootdrop:stopCollection')
AddEventHandler('lootdrop:stopCollection', function()
    isCollecting = false
    
    -- Stoppe die Unique Progressbar
    TriggerEvent('unique_progressbar:Stop')
end)

-- Belohnungsanzeige wurde entfernt

-- Hauptthread für Interaktionen
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        
        if currentDrop then
            local playerPed = PlayerPedId()
            local playerCoords = GetEntityCoords(playerPed)
            local dropCoords = vector3(currentDrop.position.x, currentDrop.position.y, currentDrop.position.z)
            local distance = #(playerCoords - dropCoords)
            
            -- Zeichne immer die Kampfzone als Bubble, unabhängig von der Entfernung
            -- Verwende einen größeren und intensiveren Marker für bessere Sichtbarkeit
            DrawMarker(28, dropCoords.x, dropCoords.y, dropCoords.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 
                Config.CombatZoneRadius, Config.CombatZoneRadius, Config.CombatZoneRadius, 138, 43, 226, 200, false, false, 2, nil, nil, false)
            
            -- Kampfzonen-Erkennung
            if distance <= Config.CombatZoneRadius then
                if not inCombatZone then
                    inCombatZone = true
                    -- Benachrichtigung beim Betreten der Kampfzone
                    TriggerEvent('chat:addMessage', {
                        color = {255, 0, 0},
                        multiline = true,
                        args = {"WARNUNG", "Du hast die Lootdrop-Kampfzone betreten!"}
                    })
                end
                
                -- Interaktionsbereich
                if not isCollecting and distance <= Config.InteractionDistance then
                    if not inDropZone then
                        inDropZone = true
                        TriggerServerEvent('lootdrop:reenteredArea')
                    end
                    
                    -- Zeige Hilfetext an
                    DrawMarker(1, dropCoords.x, dropCoords.y, dropCoords.z - 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 
                        2.0, 2.0, 1.0, 255, 0, 255, 100, false, true, 2, false, nil, nil, false)
                    
                    if distance <= 2.0 then
                        -- Verwende native FiveM Funktion statt ESX.ShowHelpNotification
                        BeginTextCommandDisplayHelp('STRING')
                        AddTextComponentSubstringPlayerName('Drücke ~INPUT_CONTEXT~ um den Lootdrop zu aktivieren')
                        EndTextCommandDisplayHelp(0, false, true, -1)
                        
                        if IsControlJustReleased(0, 38) then -- E Taste
                            TriggerServerEvent('lootdrop:activateDrop')
                        end
                    end
                else
                    if inDropZone then
                        inDropZone = false
                    end
                end
            else
                if inCombatZone then
                    inCombatZone = false
                    -- Benachrichtigung beim Verlassen der Kampfzone
                    TriggerEvent('chat:addMessage', {
                        color = {0, 255, 0},
                        multiline = true,
                        args = {"INFO", "Du hast die Lootdrop-Kampfzone verlassen."}
                    })
                end
                
                if inDropZone then
                    inDropZone = false
                end
            end
        else
            Citizen.Wait(500)
        end
    end
end)

-- Thread zur Überwachung und Wiederherstellung der Kampffähigkeiten
Citizen.CreateThread(function()
    local lastRestoreTime = 0
    
    while true do
        Citizen.Wait(3000) -- Überprüfe alle 3 Sekunden
        
        -- Nur ausführen, wenn ein aktiver Lootdrop existiert und der Spieler in der Kampfzone ist
        if currentDrop and inCombatZone and not isDead then
            local playerPed = PlayerPedId()
            local currentTime = GetGameTimer()
            local currentWeapon = GetSelectedPedWeapon(playerPed)
            
            -- Überprüfe, ob der Spieler keine Waffe hat oder im Ragdoll-Modus ist (mit Cooldown)
            if (currentTime - lastRestoreTime > 10000) and 
               (currentWeapon == GetHashKey("WEAPON_UNARMED")) then
                
                -- Stelle die Kampffähigkeiten wieder her
                ClearPedTasksImmediately(playerPed)
                SetEnableHandcuffs(playerPed, false)
                SetPedCanSwitchWeapon(playerPed, true)
                NetworkSetFriendlyFireOption(true)
                SetCanAttackFriendly(playerPed, true, true)
                FreezeEntityPosition(playerPed, false)
                
                -- Gib dem Spieler eine Waffe
                GiveWeaponToPed(playerPed, GetHashKey("WEAPON_PISTOL"), 255, false, true)
                
                -- Aktualisiere den Zeitstempel
                lastRestoreTime = currentTime
                
                -- Benachrichtige den Spieler (nur einmal alle 10 Sekunden)
                TriggerEvent('chat:addMessage', {
                    color = {255, 255, 0},
                    multiline = true,
                    args = {"KAMPFZONE", "Deine Kampffähigkeiten wurden wiederhergestellt!"}
                })
            end
        end
    end
end)

-- Thread für Respawn in der Kampfzone
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1000)
        
        -- Nur ausführen, wenn ein aktiver Lootdrop existiert und der Spieler in der Kampfzone ist
        if currentDrop and inCombatZone then
            local playerPed = PlayerPedId()
            
            -- Prüfe, ob Spieler tot ist
            if IsEntityDead(playerPed) and not isDead then
                isDead = true
                respawnTimer = Config.RespawnTime
                
                -- Zeige Respawn-Countdown an
                Citizen.CreateThread(function()
                    -- Zeige Benachrichtigung, dass automatischer Respawn aktiviert ist
                    TriggerEvent('chat:addMessage', {
                        color = {255, 165, 0},
                        multiline = true,
                        args = {"KAMPFZONE", "Du wirst in 15 Sekunden automatisch wiederbelebt!"}
                    })
                    
                    -- Countdown-Schleife
                    while respawnTimer > 0 and isDead and inCombatZone and currentDrop do
                        -- Zeige verbleibende Zeit an
                        TriggerEvent('chat:addMessage', {
                            color = {255, 255, 0},
                            multiline = false,
                            args = {"RESPAWN", "Respawn in " .. respawnTimer .. " Sekunden..."}
                        })
                        respawnTimer = respawnTimer - 1
                        Citizen.Wait(1000)
                    end
                    
                    -- Respawn nach Ablauf des Timers, aber nur wenn alle Bedingungen noch erfüllt sind
                    if isDead and inCombatZone and currentDrop then
                        local dropCoords = vector3(currentDrop.position.x, currentDrop.position.y, currentDrop.position.z)
                        
                        -- Finde den aktuellen Lootdrop-Index
                        local dropIndex = 0
                        for i, location in ipairs(Config.DropLocations) do
                            if math.abs(location.x - currentDrop.position.x) < 1.0 and 
                               math.abs(location.y - currentDrop.position.y) < 1.0 then
                                dropIndex = i
                                break
                            end
                        end
                        
                        -- Wähle einen zufälligen Respawn-Punkt für diesen Lootdrop
                        local respawnPoint = nil
                        if dropIndex > 0 and Config.RespawnPoints[dropIndex] then
                            local respawnPoints = Config.RespawnPoints[dropIndex]
                            respawnPoint = respawnPoints[math.random(#respawnPoints)]
                        end
                        
                        -- Wenn kein passender Respawn-Punkt gefunden wurde, verwende Fallback-Methode
                        local safeX, safeY, safeZ
                        if respawnPoint then
                            safeX = respawnPoint.x
                            safeY = respawnPoint.y
                            safeZ = respawnPoint.z
                            
                            -- Verwende festen Respawn-Punkt
                        else
                            -- Fallback: Zufällige Position innerhalb der Bubble
                            local radius = math.random() * (Config.CombatZoneRadius * 0.7)
                            local angle = math.random() * 2 * math.pi
                            safeX = dropCoords.x + radius * math.cos(angle)
                            safeY = dropCoords.y + radius * math.sin(angle)
                            
                            -- Finde die Bodenhöhe an dieser Position
                            local groundFound = false
                            for i = 0, 10 do
                                safeZ, groundFound = GetGroundZFor_3dCoord(safeX, safeY, 9999.0, false)
                                if groundFound then
                                    break
                                end
                                Citizen.Wait(100)
                            end
                            
                            -- Wenn kein Boden gefunden wurde, verwende die Höhe des Lootdrops
                            if not groundFound then
                                safeZ = dropCoords.z
                            end
                            
                            -- Verwende Fallback-Respawn-Punkt
                        end
                        
                        -- Verwende die Server-Revive-Funktion
                        TriggerServerEvent('lootdrop:revivePlayer')
                        
                        -- Warte einen Moment, bis der Spieler wiederbelebt ist
                        Citizen.Wait(1000)
                        
                        -- Teleportiere den Spieler zur sicheren Position
                        SetEntityCoords(PlayerPedId(), safeX, safeY, safeZ + 0.5, false, false, false, false) -- +0.5 um sicherzustellen, dass der Spieler über dem Boden ist
                        
                        -- Gib dem Spieler etwas Rüstung für den Kampf
                        SetPedArmour(PlayerPedId(), 50)
                        
                        -- Stelle sicher, dass der Spieler alle Kontrollen zurückerhält
                        Citizen.Wait(500)
                        local playerPed = PlayerPedId()
                        ClearPedTasksImmediately(playerPed)
                        SetEnableHandcuffs(playerPed, false)
                        SetPedCanSwitchWeapon(playerPed, true)
                        NetworkSetFriendlyFireOption(true)
                        SetCanAttackFriendly(playerPed, true, true)
                        FreezeEntityPosition(playerPed, false)
                        GiveWeaponToPed(playerPed, GetHashKey("WEAPON_PISTOL"), 255, false, true)
                        
                        -- Zeige eine Benachrichtigung an
                        TriggerEvent('chat:addMessage', {
                            color = {0, 255, 0},
                            multiline = true,
                            args = {"KAMPFZONE", "Du wurdest wiederbelebt und kannst weiterkämpfen!"}
                        })
                        
                        TriggerEvent('chat:addMessage', {
                            color = {0, 255, 0},
                            multiline = true,
                            args = {"RESPAWN", "Du wurdest in der Lootdrop-Kampfzone wiederbelebt!"}
                        })
                        
                        isDead = false
                        
                        -- Überprüfe nach einer Sekunde, ob der Respawn erfolgreich war
                        Citizen.CreateThread(function()
                            Citizen.Wait(1000)
                            if IsEntityDead(PlayerPedId()) then
                                -- Wenn der Spieler immer noch tot ist, versuche es direkt mit dem Event
                                TriggerEvent('chat:addMessage', {
                                    color = {255, 0, 0},
                                    multiline = true,
                                    args = {"RESPAWN", "Respawn fehlgeschlagen, versuche direkte Methode..."}
                                })
                                
                                -- Direkte Methode
                                TriggerEvent('esx_ambulancejob:revive')
                                Citizen.Wait(500)
                                SetEntityCoords(PlayerPedId(), safeX, safeY, safeZ, false, false, false, false)
                            end
                            
                            -- Stelle sicher, dass der Spieler alle Kontrollen zurückerhält (zweiter Versuch)
                            Citizen.Wait(1000)
                            local playerPed = PlayerPedId()
                            ClearPedTasksImmediately(playerPed)
                            SetEnableHandcuffs(playerPed, false)
                            SetPedCanSwitchWeapon(playerPed, true)
                            NetworkSetFriendlyFireOption(true)
                            SetCanAttackFriendly(playerPed, true, true)
                            FreezeEntityPosition(playerPed, false)
                            GiveWeaponToPed(playerPed, GetHashKey("WEAPON_PISTOL"), 255, false, true)
                            
                            -- Zeige eine zusätzliche Benachrichtigung an
                            TriggerEvent('chat:addMessage', {
                                color = {255, 255, 0},
                                multiline = true,
                                args = {"KAMPFZONE", "Deine Kampffähigkeiten wurden wiederhergestellt!"}
                            })
                        end)
                    else
                        -- Wenn der Lootdrop während des Countdowns verschwunden ist
                        if not currentDrop and isDead then
                            TriggerEvent('chat:addMessage', {
                                color = {255, 0, 0},
                                multiline = true,
                                args = {"LOOTDROP", "Automatischer Respawn deaktiviert - Lootdrop ist nicht mehr aktiv."}
                            })
                            isDead = false -- Zurücksetzen, damit andere Skripte funktionieren können
                        end
                    end
                end)
            end
        elseif isDead and not currentDrop then
            -- Wenn der Spieler tot ist, aber der Lootdrop nicht mehr aktiv ist
            isDead = false -- Zurücksetzen, damit andere Skripte funktionieren können
        end
    end
end)

-- Thread für Weitbereichs-Sichtbarkeit wurde entfernt, da nur die Bubble angezeigt werden soll