-- UI-Funktionen für das Lootdrop-System

-- ESX initialisieren
local ESX = nil
Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(0)
    end
end)

-- Funktion zum Initialisieren der NUI
Citizen.CreateThread(function()
    -- Verstecke UI beim Start
    SendNUIMessage({
        action = 'hideUI'
    })
end)

-- Funktion zum Anzeigen von Benachrichtigungen mit Fallback-Option
function ShowNotification(type, title, message, duration)
    -- Versuche zuerst delta_hud zu verwenden
    local eventName = 'delta_hud:notification'
    
    -- Sende Event mit Fallback zu ESX Benachrichtigungen
    local success = pcall(function()
        TriggerEvent(eventName, type, title, message, duration)
    end)
    
    -- Wenn delta_hud nicht verfügbar ist, verwende native FiveM Benachrichtigungen
    if not success then
        local notifText = title .. ': ' .. message
        if type == 'error' then
            SetNotificationTextEntry('STRING')
            AddTextComponentString('~r~' .. notifText)
            DrawNotification(false, false)
        elseif type == 'warning' then
            SetNotificationTextEntry('STRING')
            AddTextComponentString('~y~' .. notifText)
            DrawNotification(false, false)
        elseif type == 'success' then
            SetNotificationTextEntry('STRING')
            AddTextComponentString('~g~' .. notifText)
            DrawNotification(false, false)
        else
            SetNotificationTextEntry('STRING')
            AddTextComponentString('~b~' .. notifText)
            DrawNotification(false, false)
        end
    end
end

-- Funktion zum Anzeigen von Ankündigungen mit Fallback-Option
function ShowAnnouncement(title, message, duration)
    -- Versuche zuerst delta_hud zu verwenden
    local eventName = 'delta_hud:announcement'
    
    -- Sende Event mit Fallback zu ESX Benachrichtigungen
    local success = pcall(function()
        TriggerEvent(eventName, title, message, duration)
    end)
    
    -- Wenn delta_hud nicht verfügbar ist, verwende ESX Benachrichtigungen
    if not success then
        TriggerEvent('chat:addMessage', {
            color = {255, 0, 255},
            multiline = true,
            args = {title, message}
        })
    end
end

-- Registriere NUI-Callback für das Schließen der UI
RegisterNUICallback('closeUI', function(data, cb)
    SendNUIMessage({
        action = 'hideUI'
    })
    cb('ok')
end)