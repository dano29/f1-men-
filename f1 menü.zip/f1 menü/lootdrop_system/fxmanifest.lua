fx_version 'cerulean'
game 'gta5'

author 'Your Name'
description 'ESX Lootdrop System with Dano Reward System UI Style'
version '1.0.0'

shared_scripts {
    'config.lua'
}

client_scripts {
    'client/main.lua',
    'client/ui.lua'
}

server_scripts {
    'server/main.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js',
    'html/img/*.png'
}

dependencies {
    'es_extended'
}