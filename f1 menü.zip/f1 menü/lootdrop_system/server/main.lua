-- ESX initialisieren
local ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
local activeDrop = nil
local activeCollector = nil
local dropTimeout = nil

-- Hilfsfunktion zum Senden von Benachrichtigungen mit Fallback
local function SendNotification(target, type, title, message, duration)
    -- Versuche zuerst delta_hud zu verwenden
    local success = pcall(function()
        TriggerClientEvent('delta_hud:notification', target, type, title, message, duration)
    end)
    
    -- Wenn delta_hud nicht verfügbar ist, verwende ESX Benachrichtigungen
    if not success then
        if type == 'error' then
            TriggerClientEvent('esx:showNotification', target, '~r~' .. title .. ': ' .. message)
        elseif type == 'warning' then
            TriggerClientEvent('esx:showNotification', target, '~y~' .. title .. ': ' .. message)
        elseif type == 'success' then
            TriggerClientEvent('esx:showNotification', target, '~g~' .. title .. ': ' .. message)
        else
            TriggerClientEvent('esx:showNotification', target, '~b~' .. title .. ': ' .. message)
        end
    end
end

-- Hilfsfunktion zum Senden von Ankündigungen mit Fallback
local function SendAnnouncement(target, title, message, duration)
    -- Versuche zuerst delta_hud zu verwenden
    local success = pcall(function()
        TriggerClientEvent('delta_hud:announcement', target, title, message, duration)
    end)
    
    -- Wenn delta_hud nicht verfügbar ist, verwende Chat-Nachrichten
    if not success then
        TriggerClientEvent('chat:addMessage', target, {
            color = {255, 0, 255},
            multiline = true,
            args = {title, message}
        })
    end
end

-- Funktion zum Überprüfen der Lootdrop-Zeiten
local function CheckLootdropTimes()
    local currentTime = os.date("*t")
    local currentHour, currentMinute = currentTime.hour, currentTime.min
    
    -- Überprüfe gewöhnliche Drops
    for _, time in ipairs(Config.CommonDropTimes) do
        if currentHour == time.hour and currentMinute == time.minute and not activeDrop then
            StartLootdrop(false)
            break
        end
    end
    
    -- Überprüfe exklusive Drops
    for _, time in ipairs(Config.ExclusiveDropTimes) do
        if currentHour == time.hour and currentMinute == time.minute and not activeDrop then
            StartLootdrop(true)
            break
        end
    end
end

-- Funktion zum Starten eines Lootdrops
function StartLootdrop(isExclusive)
    if activeDrop then return end
    
    -- Wähle zufällige Position
    local dropLocation = Config.DropLocations[math.random(#Config.DropLocations)]
    
    -- Erstelle Lootdrop
    activeDrop = {
        position = dropLocation,
        isExclusive = isExclusive,
        startTime = os.time(),
        collected = false
    }
    
    -- Sende Lootdrop an alle Clients
    TriggerClientEvent('lootdrop:createDrop', -1, activeDrop)
    
    -- Sende Ankündigung an alle Spieler
    SendAnnouncement(-1, Config.Announcements.landed.title, Config.Announcements.landed.message, Config.Announcements.landed.duration)
    
    -- Setze Timeout für den Lootdrop
    dropTimeout = SetTimeout(Config.DropDuration, function()
        if activeDrop and not activeDrop.collected then
            TriggerClientEvent('lootdrop:removeDrop', -1)
            SendAnnouncement(-1, Config.Announcements.disappeared.title, Config.Announcements.disappeared.message, Config.Announcements.disappeared.duration)
            activeDrop = nil
            activeCollector = nil
        end
    end)
end

-- Funktion zum Auswählen einer zufälligen Belohnung
local function GetRandomReward(isExclusive)
    local rewards = isExclusive and Config.ExclusiveRewards or Config.CommonRewards
    local totalChance = 0
    
    for _, reward in ipairs(rewards) do
        totalChance = totalChance + reward.chance
    end
    
    local randomNum = math.random(totalChance)
    local currentChance = 0
    
    for _, reward in ipairs(rewards) do
        currentChance = currentChance + reward.chance
        if randomNum <= currentChance then
            return reward
        end
    end
    
    return rewards[1] -- Fallback
end

-- Event wenn ein Spieler versucht, den Lootdrop zu aktivieren
RegisterNetEvent('lootdrop:activateDrop')
AddEventHandler('lootdrop:activateDrop', function()
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if not activeDrop or activeDrop.collected or activeCollector then
        return
    end
    
    activeCollector = {
        id = source,
        startTime = os.time(),
        timeRemaining = Config.CollectionTime,
        completed = false
    }
    
    -- Informiere den Spieler
    SendNotification(source, Config.Notifications.participation.type, 
        Config.Notifications.participation.title, Config.Notifications.participation.message, 
        Config.Notifications.participation.duration)
    
    -- Starte den Collection-Prozess für den Spieler
    TriggerClientEvent('lootdrop:startCollection', source, Config.CollectionTime)
end)

-- Event wenn ein Spieler den Lootdrop-Bereich verlässt
RegisterNetEvent('lootdrop:leftArea')
AddEventHandler('lootdrop:leftArea', function()
    local source = source
    
    if activeCollector and activeCollector.id == source and not activeCollector.completed then
        -- Speichere die verbleibende Zeit
        activeCollector.timeRemaining = activeCollector.timeRemaining - ((os.time() - activeCollector.startTime) * 1000)
        
        -- Informiere den Spieler
        SendNotification(source, Config.Notifications.lost.type, 
            Config.Notifications.lost.title, Config.Notifications.lost.message, 
            Config.Notifications.lost.duration)
        
        -- Stoppe den Collection-Prozess für den Spieler
        TriggerClientEvent('lootdrop:stopCollection', source)
        
        -- Setze den aktiven Sammler zurück
        activeCollector = nil
    end
end)

-- Event wenn ein Spieler den Lootdrop-Bereich wieder betritt
RegisterNetEvent('lootdrop:reenteredArea')
AddEventHandler('lootdrop:reenteredArea', function()
    local source = source
    
    if activeDrop and not activeDrop.collected and not activeCollector then
        -- Informiere den Spieler
        SendNotification(source, Config.Notifications.help.type, 
            Config.Notifications.help.title, Config.Notifications.help.message, 
            Config.Notifications.help.duration)
    end
end)

-- Event wenn ein Spieler den Lootdrop erfolgreich einsammelt
RegisterNetEvent('lootdrop:completeCollection')
AddEventHandler('lootdrop:completeCollection', function()
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if not activeDrop or not activeCollector or activeCollector.id ~= source then
        return
    end
    
    -- Markiere als eingesammelt
    activeDrop.collected = true
    activeCollector.completed = true
    
    -- Wähle Belohnung
    local reward = GetRandomReward(activeDrop.isExclusive)
    
    -- Gib Belohnung
    if string.find(reward.name, "weapon_") then
        xPlayer.addWeapon(reward.name, 0)
    elseif reward.name == "money" then
        xPlayer.addMoney(reward.count)
    elseif reward.name == "black_money" then
        xPlayer.addAccountMoney('black_money', reward.count)
    else
        xPlayer.addInventoryItem(reward.name, reward.count)
    end
    
    -- Informiere den Spieler über die Belohnung (nur Benachrichtigung, keine UI)
    SendNotification(source, 'success', 'Lootdrop', 'Du hast ' .. reward.label .. ' erhalten!', 5000)
    
    -- Sende Ankündigung an alle Spieler
    SendAnnouncement(-1, Config.Announcements.collected.title, Config.Announcements.collected.message, Config.Announcements.collected.duration)
    
    -- Entferne den Lootdrop
    TriggerClientEvent('lootdrop:removeDrop', -1)
    
    -- Setze Variablen zurück
    if dropTimeout then
        clearTimeout(dropTimeout)
        dropTimeout = nil
    end
    
    activeDrop = nil
    activeCollector = nil
end)

-- Überprüfe Lootdrop-Zeiten jede Minute
Citizen.CreateThread(function()
    while true do
        CheckLootdropTimes()
        Citizen.Wait(60000) -- Warte eine Minute
    end
end)

-- Event wenn ein Spieler den Server verlässt
AddEventHandler('playerDropped', function()
    local source = source
    
    if activeCollector and activeCollector.id == source then
        activeCollector = nil
    end
end)

-- Debug-Befehl zum manuellen Auslösen eines Lootdrops (nur für Admins)
RegisterCommand('forcedrop', function(source, args)
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if xPlayer.getGroup() == 'admin' then
        local isExclusive = args[1] == 'exclusive'
        StartLootdrop(isExclusive)
        -- Verwende unsere eigene Benachrichtigungsfunktion statt xPlayer.showNotification
        SendNotification(source, 'success', 'Lootdrop', 'Lootdrop wurde manuell ausgelöst.', 5000)
    end
end, false)

-- Admin-Befehl zum Auslösen eines gewöhnlichen Lootdrops
RegisterCommand('lootdrop', function(source, args)
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if xPlayer.getGroup() == 'admin' then
        -- Starte einen gewöhnlichen Lootdrop (isExclusive = false)
        StartLootdrop(false)
        
        -- Benachrichtige den Admin
        SendNotification(source, 'success', 'Lootdrop', 'Gewöhnlicher Lootdrop wurde ausgelöst!', 5000)
        
        -- Logge die Aktion (optional)
        print(GetPlayerName(source) .. ' hat einen gewöhnlichen Lootdrop ausgelöst.')
    else
        -- Benachrichtige den Spieler, dass er keine Berechtigung hat
        SendNotification(source, 'error', 'Lootdrop', 'Du hast keine Berechtigung für diesen Befehl!', 5000)
    end
end, false)

-- Funktion zum Wiederbeleben eines Spielers (für die Kampfzone)
RegisterNetEvent('lootdrop:revivePlayer')
AddEventHandler('lootdrop:revivePlayer', function()
    local source = source
    
    -- Überprüfe, ob der Spieler in der Kampfzone ist
    if activeDrop then
        -- Verwende die korrekte Revive-Funktion
        TriggerClientEvent("esx_ambulancejob:revive", source)
        
        -- Benachrichtige den Spieler
        SendNotification(source, 'success', 'KAMPFZONE', 'Du wurdest wiederbelebt und kannst weiterkämpfen!', 5000)
        
        -- Gib dem Spieler etwas Zeit, um sich zu orientieren
        Citizen.Wait(500)
        
        -- Sende eine zusätzliche Benachrichtigung
        SendNotification(source, 'warning', 'KAMPFZONE', 'Vorsicht! Du befindest dich in einer aktiven Kampfzone!', 5000)
    end
end)