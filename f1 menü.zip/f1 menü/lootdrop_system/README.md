# FiveM ESX Lootdrop-System

Ein Lootdrop-System für FiveM ESX Server, inspiriert vom UI-Stil des Dano Reward Systems.

## Features

### Zeitbasierte Lootdrops
- **Gewöhnliche Lootdrops** (alle 4 Stunden): 02:00, 08:00, 14:00, 20:00 Uhr
- **Exklusive Lootdrops** (alle 8 Stunden): 04:00, 12:00, 20:00 Uhr
- Automatische Auslösung basierend auf der Serverzeit

### Lootdrop-Mechanik
- Ein Lootdrop-Prop erscheint an einer zufälligen Position auf der Map
- Ein Map-Blip markiert den Drop für alle Spieler
- Spieler müssen innerhalb von 15m sein und E drücken, um den Loot zu aktivieren
- Nach Aktivierung muss der Spieler 2 Minuten im Umkreis bleiben
- Der Fortschritt pausiert, wenn der Spieler sich entfernt

### Belohnungen
- **Gewöhnlich**: Magazine, Westen, Waffenaufsätze
- **Exklusiv**: Pistole, Schwere Pistole, .50er Pistole

### Benachrichtigungen
- Verschiedene Benachrichtigungen für Teilnahme, Warnungen und Fehler
- Hilfehinweise beim Nähern an den Lootdrop
- Serverweite Ankündigungen für wichtige Ereignisse
- Unterstützung für delta_hud (optional)

### UI-Design
- Ansprechendes Design mit dunklem Hintergrund und leuchtenden Farben
- Live-Timer und Fortschrittsbalken
- Belohnungsanzeige nach erfolgreicher Sammlung

## Installation

1. Kopieren Sie den Ordner `lootdrop_system` in Ihren FiveM-Ressourcenordner
2. Fügen Sie `ensure lootdrop_system` zu Ihrer `server.cfg` hinzu
3. Starten oder neustarten Sie Ihren Server

## Konfiguration

Alle Einstellungen können in der `config.lua` angepasst werden:
- Lootdrop-Zeiten
- Lootdrop-Positionen
- Belohnungen und deren Wahrscheinlichkeiten
- Benachrichtigungstexte
- UI-Einstellungen

## Admin-Befehle

- `/lootdrop` - Löst einen gewöhnlichen Lootdrop aus (nur für Admins)
- `/forcedrop` - Löst einen gewöhnlichen Lootdrop aus (nur für Admins)
- `/forcedrop exclusive` - Löst einen exklusiven Lootdrop aus (nur für Admins)

## Abhängigkeiten

- ESX Framework
- delta_hud (optional, für verbesserte Benachrichtigungen)

## Hinweise

- Das System verwendet standardmäßig ESX-Benachrichtigungen, wenn delta_hud nicht verfügbar ist
- Alle Lootdrop-Positionen können in der Konfigurationsdatei angepasst werden
- Die Belohnungen und deren Wahrscheinlichkeiten sind vollständig konfigurierbar