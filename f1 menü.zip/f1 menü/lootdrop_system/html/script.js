// Lootdrop System UI Script
// Keine Funktionalität mehr nötig, da wir die Unique Progressbar verwenden

$(function() {
    // Listener für NUI-Nachrichten (falls in Zukunft benötigt)
    window.addEventListener('message', function(event) {
        // Keine Aktionen mehr nötig
    });
});