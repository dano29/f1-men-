ESX = nil
TriggerEvent("esx:getSharedObject", function(obj) ESX = obj end)


CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Wait(10)
	end
end)

RegisterServerEvent('bfs_killfeed:add')
AddEventHandler('bfs_killfeed:add', function(killer, victim, image, noScoped, headshot, driveBy, dist, target)
	local xPlayer = ESX.GetPlayerFromId(killer.sourceId)
	local xTarget = ESX.GetPlayerFromId(victim.sourceId)

killer.name = GetPlayerName(source)
if xTarget then
	victim.name = GetPlayerName(xTarget.source)
else
	victim.name = "Unknown"
end

	TriggerClientEvent('bfs_killfeed:addCL', -1, killer, victim, image, noScoped, headshot, driveBy, dist)
end)

--killer.name = xPlayer.getName()
--victim.name = xTarget.getName()

--killer.name = GetPlayerName(source)
--victim.name = GetPlayerName(xTarget.source)
