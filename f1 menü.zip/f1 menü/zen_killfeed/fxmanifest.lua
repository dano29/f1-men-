

lua54 'yes'
fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author 'Türkeii / Leonis'
description 'AN Kill Feed' -- Join Discord for Support: https://discord.gg/utopia-dev
version '1.0.0'
ui_page 'html/index.html'
shared_script 'config.lua'
client_script 'client.lua'
server_script 'server.lua'
escrow_ignore {
	'*',
	'*/*',
}
files {
	'html/index.html',
	'html/main.js',
	'html/style.css',
	'html/images/*',
	'html/valo.ttf',
}
dependency '/assetpacks'


