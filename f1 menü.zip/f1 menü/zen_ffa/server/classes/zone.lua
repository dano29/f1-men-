local L0_1, L1_1
L0_1 = {}
Zone = L0_1
L0_1 = Zone
L1_1 = Zone
L0_1.__index = L1_1
L0_1 = Zone
L1_1 = {}
L0_1.zones = L1_1
L0_1 = {}
L0_1.STANDARD = "standard"
L0_1.CUSTOM = "custom"
ZoneType = L0_1
L0_1 = Zone
function L1_1(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2, A6_2, A7_2, A8_2, A9_2, A10_2)
  local L11_2, L12_2, L13_2
  L11_2 = setmetatable
  L12_2 = {}
  L13_2 = Zone
  L11_2 = L11_2(L12_2, L13_2)
  L12_2 = Zone
  L12_2 = L12_2.zones
  L12_2 = #L12_2
  L12_2 = L12_2 + 1
  L11_2.id = L12_2
  L11_2.type = A0_2
  L11_2.name = A1_2
  L11_2.map = A9_2
  L11_2.position = A2_2
  L11_2.size = A3_2
  L11_2.currentPlayer = 0
  L11_2.maxPlayers = A4_2
  L11_2.gunType = A5_2
  L11_2.guns = A6_2
  L11_2.image = A7_2
  L12_2 = B_SERVICE
  L12_2 = L12_2.StartDimensionCount
  L13_2 = Zone
  L13_2 = L13_2.zones
  L13_2 = #L13_2
  L12_2 = L12_2 + L13_2
  L11_2.dimension = L12_2
  L11_2.spawnPoints = A8_2
  L11_2.password = A10_2
  function L12_2()
    local L0_3, L1_3
    L0_3 = L11_2.id
    return L0_3
  end
  L11_2.getId = L12_2
  function L12_2(A0_3)
    local L1_3
    L1_3 = L11_2.password
    if L1_3 == A0_3 then
      L1_3 = true
      return L1_3
    else
      L1_3 = false
      return L1_3
    end
  end
  L11_2.checkPassword = L12_2
  function L12_2()
    local L0_3, L1_3
    L0_3 = L11_2.type
    return L0_3
  end
  L11_2.getType = L12_2
  function L12_2()
    local L0_3, L1_3
    L0_3 = L11_2.dimension
    return L0_3
  end
  L11_2.getDimension = L12_2
  function L12_2()
    local L0_3, L1_3
    L0_3 = L11_2.spawnPoints
    return L0_3
  end
  L11_2.getSpawnPoints = L12_2
  function L12_2()
    local L0_3, L1_3
    L0_3 = L11_2.guns
    return L0_3
  end
  L11_2.getGuns = L12_2
  function L12_2()
    local L0_3, L1_3
    L0_3 = L11_2.gunType
    return L0_3
  end
  L11_2.getGunType = L12_2
  function L12_2()
    local L0_3, L1_3
    L0_3 = L11_2.image
    return L0_3
  end
  L11_2.getImage = L12_2
  function L12_2()
    local L0_3, L1_3
    L0_3 = L11_2.name
    return L0_3
  end
  L11_2.getName = L12_2
  function L12_2()
    local L0_3, L1_3
    L0_3 = L11_2.position
    return L0_3
  end
  L11_2.getPosition = L12_2
  function L12_2()
    local L0_3, L1_3
    L0_3 = L11_2.size
    return L0_3
  end
  L11_2.getSize = L12_2
  function L12_2()
    local L0_3, L1_3
    L0_3 = L11_2.maxPlayers
    return L0_3
  end
  L11_2.getMaxPlayers = L12_2
  function L12_2()
    local L0_3, L1_3
    L0_3 = L11_2.currentPlayer
    return L0_3
  end
  L11_2.getCurrentPlayer = L12_2
  function L12_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    if not A0_3 then
      return
    end
    L1_3 = A0_3.loadout
    L1_3 = #L1_3
    L2_3 = 1
    L3_3 = -1
    for L4_3 = L1_3, L2_3, L3_3 do
      L5_3 = A0_3.addWeaponAmmo
      L6_3 = A0_3.loadout
      L6_3 = L6_3[L4_3]
      L6_3 = L6_3.name
      L7_3 = 9999
      L5_3(L6_3, L7_3)
    end
  end
  L11_2.addWeaponAmmo = L12_2
  function L12_2()
    local L0_3, L1_3
    L0_3 = L11_2.currentPlayer
    L0_3 = L0_3 + 1
    L11_2.currentPlayer = L0_3
    L0_3 = L11_2.updateToAllPlayers
    L0_3()
  end
  L11_2.addPlayerCount = L12_2
  function L12_2()
    local L0_3, L1_3
    L0_3 = L11_2.currentPlayer
    if 0 == L0_3 then
      L0_3 = L11_2.updateToAllPlayers
      L0_3()
      return
    end
    L0_3 = L11_2.currentPlayer
    L0_3 = L0_3 - 1
    L11_2.currentPlayer = L0_3
    L0_3 = L11_2.updateToAllPlayers
    L0_3()
  end
  L11_2.removePlayerCount = L12_2
  function L12_2()
    local L0_3, L1_3, L2_3, L3_3
    L0_3 = L11_2.getSpawnPoints
    L0_3 = L0_3()
    L1_3 = math
    L1_3 = L1_3.random
    L2_3 = 1
    L3_3 = #L0_3
    L1_3 = L1_3(L2_3, L3_3)
    L1_3 = L0_3[L1_3]
    return L1_3
  end
  L11_2.getRandomSpawnPoint = L12_2
  function L12_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3
    L1_3 = ESX
    L1_3 = L1_3.GetPlayerFromId
    L2_3 = A0_3
    L1_3 = L1_3(L2_3)
    L2_3 = pairs
    L3_3 = L11_2.getGuns
    L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3 = L3_3()
    L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3)
    for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
      L8_3 = L1_3.addWeapon
      L9_3 = L7_3
      L10_3 = 99999
      L8_3(L9_3, L10_3)
    end
  end
  L11_2.giveZoneWeapons = L12_2
  function L12_2()
    local L0_3, L1_3, L2_3
    L0_3 = GlobalState
    L0_3 = L0_3.ffaZones
    if not L0_3 then
      L0_3 = {}
    end
    L1_3 = L11_2.id
    L2_3 = L11_2
    L0_3[L1_3] = L2_3
    L1_3 = GlobalState
    L1_3.ffaZones = L0_3
  end
  L11_2.updateToAllPlayers = L12_2
  function L12_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L0_3 = GlobalState
    L0_3 = L0_3.ffaZones
    if not L0_3 then
      L0_3 = {}
    end
    L1_3 = pairs
    L2_3 = L0_3
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L7_3 = L6_3.id
      L8_3 = L11_2.id
      if L7_3 == L8_3 then
        L0_3[L5_3] = nil
      end
    end
    L1_3 = Zone
    L1_3 = L1_3.zones
    L2_3 = L11_2.id
    L1_3[L2_3] = nil
    L1_3 = GlobalState
    L1_3.ffaZones = L0_3
  end
  L11_2.delete = L12_2
  L12_2 = Zone
  L12_2 = L12_2.zones
  L13_2 = L11_2.id
  L12_2[L13_2] = L11_2
  return L11_2
end
L0_1.new = L1_1
L0_1 = Zone
function L1_1(A0_2)
  local L1_2
  L1_2 = Zone
  L1_2 = L1_2.zones
  L1_2 = L1_2[A0_2]
  return L1_2
end
L0_1.getZoneById = L1_1
L0_1 = Zone
function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = pairs
  L2_2 = Zone
  L2_2 = L2_2.zones
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    L7_2 = L6_2.getName
    L7_2 = L7_2()
    if L7_2 == A0_2 then
      return L6_2
    end
  end
end
L0_1.getZoneByName = L1_1
