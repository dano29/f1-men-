local L0_1, L1_1
L0_1 = {}
FFAPlayer = L0_1
L0_1 = FFAPlayer
L1_1 = FFAPlayer
L0_1.__index = L1_1
L0_1 = FFAPlayer
L1_1 = {}
L0_1.players = L1_1
L0_1 = FFAPlayer
function L1_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = setmetatable
  L3_2 = {}
  L4_2 = FFAPlayer
  L2_2 = L2_2(L3_2, L4_2)
  L2_2.playerId = A0_2
  L2_2.identifier = A1_2
  L2_2.zone = nil
  L3_2 = MySQL
  L3_2 = L3_2.Sync
  L3_2 = L3_2.fetchScalar
  L4_2 = "SELECT kills FROM b_ffa WHERE identifier = @identifier"
  L5_2 = {}
  L5_2["@identifier"] = A1_2
  L3_2 = L3_2(L4_2, L5_2)
  if not L3_2 then
    L3_2 = 0
  end
  L2_2.kills = L3_2
  L3_2 = MySQL
  L3_2 = L3_2.Sync
  L3_2 = L3_2.fetchScalar
  L4_2 = "SELECT deaths FROM b_ffa WHERE identifier = @identifier"
  L5_2 = {}
  L5_2["@identifier"] = A1_2
  L3_2 = L3_2(L4_2, L5_2)
  if not L3_2 then
    L3_2 = 0
  end
  L2_2.deaths = L3_2
  L3_2 = GetPlayerName
  L4_2 = A0_2
  L3_2 = L3_2(L4_2)
  L2_2.name = L3_2
  function L3_2(A0_3)
    local L1_3, L2_3
    L1_3 = L2_2.zone
    if L1_3 then
      L1_3 = L1_3.addWeaponAmmo
    end
    L2_3 = A0_3
    L1_3(L2_3)
  end
  L2_2.refillAmmo = L3_2
  function L3_2()
    local L0_3, L1_3
    L0_3 = L2_2.zone
    return L0_3
  end
  L2_2.getZone = L3_2
  function L3_2(A0_3)
    local L1_3
    L2_2.zone = A0_3
  end
  L2_2.setZone = L3_2
  function L3_2()
    local L0_3, L1_3
    L0_3 = GetPlayerPed
    L1_3 = L2_2.playerId
    return L0_3(L1_3)
  end
  L2_2.getPed = L3_2
  function L3_2()
    local L0_3, L1_3
    L0_3 = GetEntityCoords
    L1_3 = L2_2.getPed
    L1_3 = L1_3()
    return L0_3(L1_3)
  end
  L2_2.getCoords = L3_2
  function L3_2()
    local L0_3, L1_3
    L0_3 = L2_2.identifier
    return L0_3
  end
  L2_2.getIdentifier = L3_2
  function L3_2()
    local L0_3, L1_3
    L0_3 = L2_2.name
    return L0_3
  end
  L2_2.getName = L3_2
  function L3_2()
    local L0_3, L1_3, L2_3, L3_3
    L0_3 = L2_2.getZone
    L0_3 = L0_3()
    L1_3 = ZoneType
    L1_3 = L1_3.CUSTOM
    if L0_3 == L1_3 then
      return
    end
    L0_3 = L2_2.kills
    L0_3 = L0_3 + 1
    L2_2.kills = L0_3
    L0_3 = Player
    L1_3 = L2_2.playerId
    L0_3 = L0_3(L1_3)
    L0_3 = L0_3.state
    L1_3 = L2_2.kills
    L0_3.ffaKills = L1_3
    L0_3 = MySQL
    L0_3 = L0_3.Sync
    L0_3 = L0_3.execute
    L1_3 = "INSERT INTO b_ffa (identifier, kills, deaths) VALUES (@identifier, @kills, @deaths) ON DUPLICATE KEY UPDATE kills = @kills"
    L2_3 = {}
    L3_3 = L2_2.identifier
    L2_3["@identifier"] = L3_3
    L3_3 = L2_2.kills
    L2_3["@kills"] = L3_3
    L3_3 = L2_2.deaths
    L2_3["@deaths"] = L3_3
    L0_3(L1_3, L2_3)
  end
  L2_2.addKill = L3_2
  function L3_2()
    local L0_3, L1_3, L2_3, L3_3
    L0_3 = L2_2.getZone
    L0_3 = L0_3()
    L1_3 = ZoneType
    L1_3 = L1_3.CUSTOM
    if L0_3 == L1_3 then
      return
    end
    L0_3 = L2_2.deaths
    L0_3 = L0_3 + 1
    L2_2.deaths = L0_3
    L0_3 = Player
    L1_3 = L2_2.playerId
    L0_3 = L0_3(L1_3)
    L0_3 = L0_3.state
    L1_3 = L2_2.deaths
    L0_3.ffaDeaths = L1_3
    L0_3 = MySQL
    L0_3 = L0_3.Sync
    L0_3 = L0_3.execute
    L1_3 = "INSERT INTO b_ffa (identifier, kills, deaths) VALUES (@identifier, @kills, @deaths) ON DUPLICATE KEY UPDATE deaths = @deaths"
    L2_3 = {}
    L3_3 = L2_2.identifier
    L2_3["@identifier"] = L3_3
    L3_3 = L2_2.kills
    L2_3["@kills"] = L3_3
    L3_3 = L2_2.deaths
    L2_3["@deaths"] = L3_3
    L0_3(L1_3, L2_3)
  end
  L2_2.addDeath = L3_2
  function L3_2()
    local L0_3, L1_3
    L0_3 = L2_2.kills
    return L0_3
  end
  L2_2.getKills = L3_2
  function L3_2()
    local L0_3, L1_3
    L0_3 = L2_2.deaths
    return L0_3
  end
  L2_2.getDeaths = L3_2
  function L3_2(A0_3, ...)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = TriggerClientEvent
    L2_3 = A0_3
    L3_3 = L2_2.playerId
    L4_3 = ...
    L1_3(L2_3, L3_3, L4_3)
  end
  L2_2.triggerEvent = L3_2
  function L3_2(A0_3, A1_3, A2_3, A3_3)
    local L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L4_3 = L2_2.triggerEvent
    L5_3 = "b-ffa:sendNotification"
    L6_3 = A0_3
    L7_3 = A1_3
    L8_3 = A2_3
    L9_3 = A3_3
    L4_3(L5_3, L6_3, L7_3, L8_3, L9_3)
  end
  L2_2.sendNotification = L3_2
  function L3_2()
    local L0_3, L1_3
    L0_3 = Player
    L1_3 = L2_2.playerId
    L0_3 = L0_3(L1_3)
    L0_3 = L0_3.state
    L0_3 = L0_3.ffaEntered
    return L0_3
  end
  L2_2.inFFA = L3_2
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3
    L2_3 = Zone
    L2_3 = L2_3.getZoneById
    L3_3 = A1_3
    L2_3 = L2_3(L3_3)
    if not L2_3 then
      L3_3 = L2_2.sendNotification
      L4_3 = "error"
      L5_3 = "FFA"
      L6_3 = "Die Zone existiert nicht."
      L7_3 = 5000
      return L3_3(L4_3, L5_3, L6_3, L7_3)
    end
    L3_3 = L2_3.getCurrentPlayer
    L3_3 = L3_3()
    L4_3 = L2_3.getMaxPlayers
    L4_3 = L4_3()
    if L3_3 >= L4_3 then
      L3_3 = L2_2.sendNotification
      L4_3 = "error"
      L5_3 = "FFA"
      L6_3 = "Die Zone ist voll."
      L7_3 = 5000
      return L3_3(L4_3, L5_3, L6_3, L7_3)
    end
    L3_3 = L2_2.inFFA
    L3_3 = L3_3()
    if L3_3 then
      L3_3 = L2_2.sendNotification
      L4_3 = "error"
      L5_3 = "FFA"
      L6_3 = "Du bist bereits in einer Zone."
      L7_3 = 5000
      return L3_3(L4_3, L5_3, L6_3, L7_3)
    end
    L3_3 = L2_2.saveLoadout
    L4_3 = A0_3
    L3_3 = L3_3(L4_3)
    if not L3_3 then
      L4_3 = L2_2.sendNotification
      L5_3 = "error"
      L6_3 = "FFA"
      L7_3 = "Fehler beim Speichern deines Loadouts"
      L8_3 = 5000
      return L4_3(L5_3, L6_3, L7_3, L8_3)
    end
    L4_3 = L2_2.getCoords
    L4_3 = L4_3()
    L5_3 = L2_3.giveZoneWeapons
    L6_3 = L2_2.playerId
    L5_3(L6_3)
    L5_3 = Player
    L6_3 = L2_2.playerId
    L5_3 = L5_3(L6_3)
    L5_3 = L5_3.state
    L5_3.ffaEntered = true
    L5_3 = Player
    L6_3 = L2_2.playerId
    L5_3 = L5_3(L6_3)
    L5_3 = L5_3.state
    L5_3.ffaEnteredCoords = L4_3
    L5_3 = Player
    L6_3 = L2_2.playerId
    L5_3 = L5_3(L6_3)
    L5_3 = L5_3.state
    L6_3 = L2_3.getId
    L6_3 = L6_3()
    L5_3.ffaZoneId = L6_3
    L5_3 = Player
    L6_3 = L2_2.playerId
    L5_3 = L5_3(L6_3)
    L5_3 = L5_3.state
    L6_3 = L2_2.getDeaths
    L6_3 = L6_3()
    L5_3.ffaDeaths = L6_3
    L5_3 = Player
    L6_3 = L2_2.playerId
    L5_3 = L5_3(L6_3)
    L5_3 = L5_3.state
    L6_3 = L2_2.getKills
    L6_3 = L6_3()
    L5_3.ffaKills = L6_3
    L5_3 = L2_3.getRandomSpawnPoint
    L5_3 = L5_3()
    L6_3 = SetEntityCoords
    L7_3 = L2_2.getPed
    L7_3 = L7_3()
    L8_3 = L5_3.x
    L9_3 = L5_3.y
    L10_3 = L5_3.z
    L6_3(L7_3, L8_3, L9_3, L10_3)
    L6_3 = L2_3.addPlayerCount
    L6_3()
    L6_3 = L2_2.triggerEvent
    L7_3 = "b-ffa:enteredFFA"
    L8_3 = L2_3
    L6_3(L7_3, L8_3)
    L6_3 = L2_2.sendNotification
    L7_3 = "success"
    L8_3 = "FFA"
    L9_3 = string
    L9_3 = L9_3.format
    L10_3 = "Du bist der Zone %s beigetreten."
    L11_3 = L2_3.getName
    L11_3 = L11_3()
    L9_3 = L9_3(L10_3, L11_3)
    L10_3 = 5000
    L6_3(L7_3, L8_3, L9_3, L10_3)
    L6_3 = L2_2.setZone
    L7_3 = L2_3
    L6_3(L7_3)
    L6_3 = SetPlayerRoutingBucket
    L7_3 = L2_2.playerId
    L8_3 = L2_3.getDimension
    L8_3, L9_3, L10_3, L11_3 = L8_3()
    L6_3(L7_3, L8_3, L9_3, L10_3, L11_3)
  end
  L2_2.joinZone = L3_2
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = A0_3.getLoadout
    L1_3 = L1_3()
    L2_3 = #L1_3
    L3_3 = 1
    L4_3 = -1
    for L5_3 = L2_3, L3_3, L4_3 do
      L6_3 = A0_3.removeWeapon
      L7_3 = L1_3[L5_3]
      L7_3 = L7_3.name
      L6_3(L7_3)
    end
    L2_3 = RemoveAllPedWeapons
    L3_3 = L2_2.getPed
    L3_3 = L3_3()
    L4_3 = true
    L2_3(L3_3, L4_3)
    L2_3 = {}
    A0_3.loadout = L2_3
  end
  L2_2.clearLoadout = L3_2
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L1_3 = L2_2.inFFA
    L1_3 = L1_3()
    if not L1_3 then
      L1_3 = L2_2.sendNotification
      L2_3 = "error"
      L3_3 = "FFA"
      L4_3 = "Du bist in keiner FFA Zone."
      L5_3 = 5000
      return L1_3(L2_3, L3_3, L4_3, L5_3)
    end
    L1_3 = L2_2.getZone
    L1_3 = L1_3()
    if not L1_3 then
      L2_3 = L2_2.sendNotification
      L3_3 = "error"
      L4_3 = "FFA"
      L5_3 = "Die Zone existiert nicht."
      L6_3 = 5000
      return L2_3(L3_3, L4_3, L5_3, L6_3)
    end
    L2_3 = L2_2.clearLoadout
    L3_3 = A0_3
    L2_3(L3_3)
    L2_3 = L2_2.restoreLoadout
    L3_3 = A0_3
    L2_3 = L2_3(L3_3)
    if not L2_3 then
      L3_3 = L2_2.sendNotification
      L4_3 = "error"
      L5_3 = "FFA"
      L6_3 = "Dein Loadout konnte nicht wiederhergestellt werden."
      L7_3 = 5000
      return L3_3(L4_3, L5_3, L6_3, L7_3)
    end
    L3_3 = SetPlayerRoutingBucket
    L4_3 = L2_2.playerId
    L5_3 = 0
    L3_3(L4_3, L5_3)
    L3_3 = Player
    L4_3 = L2_2.playerId
    L3_3 = L3_3(L4_3)
    L3_3 = L3_3.state
    L3_3 = L3_3.ffaEnteredCoords
    if L3_3 then
      L4_3 = SetEntityCoords
      L5_3 = L2_2.getPed
      L5_3 = L5_3()
      L6_3 = L3_3.x
      L7_3 = L3_3.y
      L8_3 = L3_3.z
      L4_3(L5_3, L6_3, L7_3, L8_3)
    end
    L4_3 = L1_3.removePlayerCount
    L4_3()
    L4_3 = Player
    L5_3 = L2_2.playerId
    L4_3 = L4_3(L5_3)
    L4_3 = L4_3.state
    L4_3.ffaZone = nil
    L4_3 = Player
    L5_3 = L2_2.playerId
    L4_3 = L4_3(L5_3)
    L4_3 = L4_3.state
    L4_3.ffaEntered = false
    L4_3 = L2_2.triggerEvent
    L5_3 = "b-ffa:leftFFA"
    L4_3(L5_3)
    L4_3 = L1_3.getType
    L4_3 = L4_3()
    L5_3 = ZoneType
    L5_3 = L5_3.CUSTOM
    if L4_3 == L5_3 then
      L4_3 = L1_3.getCurrentPlayer
      L4_3 = L4_3()
      if 0 == L4_3 then
        L4_3 = L1_3.delete
        L4_3()
      end
    end
    L4_3 = L2_2.sendNotification
    L5_3 = "success"
    L6_3 = "FFA"
    L7_3 = string
    L7_3 = L7_3.format
    L8_3 = "Du hast die Zone %s verlassen."
    L9_3 = L1_3.getName
    L9_3 = L9_3()
    L7_3 = L7_3(L8_3, L9_3)
    L8_3 = 5000
    L4_3(L5_3, L6_3, L7_3, L8_3)
  end
  L2_2.quitZone = L3_2
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    if not A0_3 then
      L1_3 = false
      return L1_3
    end
    L1_3 = A0_3.getLoadout
    L1_3 = L1_3()
    L2_3 = json
    L2_3 = L2_3.encode
    L3_3 = A0_3.getLoadout
    L4_3 = true
    L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
    L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3)
    if not L1_3 then
      L3_3 = false
      return L3_3
    end
    L3_3 = L2_2.clearLoadout
    L4_3 = A0_3
    L3_3(L4_3)
    L3_3 = MySQL
    L3_3 = L3_3.Sync
    L3_3 = L3_3.execute
    L4_3 = "INSERT INTO b_ffa (identifier, loadout, kills, deaths) VALUES (@identifier, @loadout, @kills, @deaths) ON DUPLICATE KEY UPDATE loadout = @loadout"
    L5_3 = {}
    L6_3 = A0_3.identifier
    L5_3["@identifier"] = L6_3
    L5_3["@loadout"] = L2_3
    L5_3["@kills"] = 0
    L5_3["@deaths"] = 0
    L3_3 = L3_3(L4_3, L5_3)
    L4_3 = true
    return L4_3
  end
  L2_2.saveLoadout = L3_2
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3
    if not A0_3 then
      L1_3 = false
      return L1_3
    end
    L1_3 = MySQL
    L1_3 = L1_3.Sync
    L1_3 = L1_3.fetchScalar
    L2_3 = "SELECT loadout FROM b_ffa WHERE identifier = @identifier"
    L3_3 = {}
    L4_3 = A0_3.identifier
    L3_3["@identifier"] = L4_3
    L1_3 = L1_3(L2_3, L3_3)
    if not L1_3 then
      L2_3 = false
      return L2_3
    end
    L2_3 = json
    L2_3 = L2_3.decode
    L3_3 = L1_3
    L2_3 = L2_3(L3_3)
    L1_3 = L2_3
    if not L1_3 then
      L2_3 = false
      return L2_3
    end
    L2_3 = ipairs
    L3_3 = L1_3
    L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
    for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
      L8_3 = A0_3.addWeapon
      L9_3 = L7_3.name
      L10_3 = L7_3.ammo
      L8_3(L9_3, L10_3)
      L8_3 = L7_3.components
      if L8_3 then
        L8_3 = ipairs
        L9_3 = L7_3.components
        L8_3, L9_3, L10_3, L11_3 = L8_3(L9_3)
        for L12_3, L13_3 in L8_3, L9_3, L10_3, L11_3 do
          L14_3 = A0_3.addWeaponComponent
          L15_3 = L7_3.name
          L16_3 = L13_3
          L14_3(L15_3, L16_3)
        end
      end
      L8_3 = L7_3.tintIndex
      if L8_3 then
        L8_3 = A0_3.setWeaponTint
        L9_3 = L7_3.name
        L10_3 = L7_3.tintIndex
        L8_3(L9_3, L10_3)
      end
    end
    L2_3 = true
    return L2_3
  end
  L2_2.restoreLoadout = L3_2
  L3_2 = FFAPlayer
  L3_2 = L3_2.players
  L4_2 = L2_2.identifier
  L3_2[L4_2] = L2_2
  return L2_2
end
L0_1.new = L1_1
L0_1 = FFAPlayer
function L1_1(A0_2)
  local L1_2
  L1_2 = FFAPlayer
  L1_2 = L1_2.players
  L1_2 = L1_2[A0_2]
  return L1_2
end
L0_1.getPlayerFromIdentifier = L1_1
