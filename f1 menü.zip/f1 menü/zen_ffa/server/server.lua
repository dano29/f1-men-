local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1
ESX = nil
L0_1 = {}
L1_1 = print
L2_1 = false
function L3_1(...)
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = table
  L0_2 = L0_2.concat
  L1_2 = {}
  L2_2, L3_2 = ...
  L1_2[1] = L2_2
  L1_2[2] = L3_2
  L2_2 = " "
  L0_2 = L0_2(L1_2, L2_2)
  L1_2 = L1_1
  L2_2 = "^7[^5b-ffa^7] "
  L3_2 = (...)
  L2_2 = L2_2 .. L3_2
  L1_2(L2_2)
end
print = L3_1
L3_1 = exports
L3_1 = L3_1.es_extended
L4_1 = L3_1
L3_1 = L3_1.getSharedObject
L3_1 = L3_1(L4_1)
if L3_1 then
  L3_1 = exports
  L3_1 = L3_1.es_extended
  L4_1 = L3_1
  L3_1 = L3_1.getSharedObject
  L3_1 = L3_1(L4_1)
  ESX = L3_1
  L3_1 = print
  L4_1 = "ESX v2 found"
  L3_1(L4_1)
else
  L3_1 = TriggerEvent
  L4_1 = B_SERVICE
  L4_1 = L4_1.SharedObject
  L4_1 = L4_1.Server
  function L5_1(A0_2)
    local L1_2
    ESX = A0_2
  end
  L3_1(L4_1, L5_1)
  L3_1 = print
  L4_1 = "ESX v1 found"
  L3_1(L4_1)
end
L3_1 = RegisterNetEvent
L4_1 = "ffa:killed"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = TriggerClientEvent
  L2_2 = "ffa:restock"
  L3_2 = A0_2
  L1_2(L2_2, L3_2)
end
L3_1(L4_1, L5_1)
L3_1 = Citizen
L3_1 = L3_1.CreateThread
function L4_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
  L0_2 = ipairs
  L1_2 = GetPlayers
  L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2 = L1_2()
  L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
  for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
    L6_2 = ESX
    L6_2 = L6_2.GetPlayerFromId
    L7_2 = L5_2
    L6_2 = L6_2(L7_2)
    if L6_2 then
      L7_2 = Player
      L8_2 = L6_2.source
      L7_2 = L7_2(L8_2)
      L7_2 = L7_2.state
      L7_2.ffaEntered = false
    end
  end
  L0_2 = {}
  L1_2 = ipairs
  L2_2 = B_SERVICE
  L2_2 = L2_2.Zones
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    L7_2 = Zone
    L7_2 = L7_2.new
    L8_2 = L6_2.type
    L9_2 = L6_2.name
    L10_2 = L6_2.position
    L11_2 = L6_2.size
    L12_2 = L6_2.maxPlayers
    L13_2 = L6_2.gunType
    L14_2 = L6_2.guns
    L15_2 = L6_2.image
    L16_2 = L6_2.spawnPoints
    L7_2 = L7_2(L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
    L8_2 = table
    L8_2 = L8_2.insert
    L9_2 = L0_2
    L10_2 = L7_2
    L8_2(L9_2, L10_2)
    L8_2 = print
    L9_2 = "Loaded zone: "
    L10_2 = L7_2.getName
    L10_2 = L10_2()
    L9_2 = L9_2 .. L10_2
    L8_2(L9_2)
  end
  L1_2 = GlobalState
  L1_2.ffaZones = L0_2
  L1_2 = MySQL
  L1_2 = L1_2.Async
  L1_2 = L1_2.execute
  L2_2 = "CREATE TABLE IF NOT EXISTS b_ffa (identifier VARCHAR(255), kills INT(11), deaths INT(11), loadout LONGTEXT DEFAULT '[]' NOT NULL, PRIMARY KEY (identifier))"
  L3_2 = {}
  function L4_2(A0_3)
    local L1_3, L2_3
    L1_3 = print
    L2_3 = "Created table b_ffa"
    L1_3(L2_3)
    L1_3 = sendStatsWebhook
    L1_3()
  end
  L1_2(L2_2, L3_2, L4_2)
  L1_2 = true
  L2_1 = L1_2
end
L3_1(L4_1)
L3_1 = RegisterNetEvent
L4_1 = "b_ffa:getFFAZones"
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = source
  L1_2 = ESX
  L1_2 = L1_2.GetPlayerFromId
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    return
  end
  while true do
    L2_2 = L2_1
    if false ~= L2_2 then
      break
    end
    L2_2 = print
    L3_2 = "waiting for zones to load.."
    L2_2(L3_2)
    L2_2 = Wait
    L3_2 = 1000
    L2_2(L3_2)
  end
  L2_2 = TriggerClientEvent
  L3_2 = "b_ffa:setFFAZones"
  L4_2 = L0_2
  L5_2 = GlobalState
  L5_2 = L5_2.ffaZones
  L2_2(L3_2, L4_2, L5_2)
end
L3_1(L4_1, L5_1)
function L3_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = MySQL
  L0_2 = L0_2.Async
  L0_2 = L0_2.fetchAll
  L1_2 = "SELECT b_ffa.identifier, b_ffa.kills, b_ffa.deaths, users.firstname, users.lastname FROM b_ffa INNER JOIN users ON b_ffa.identifier = users.identifier ORDER BY b_ffa.kills DESC LIMIT 10"
  L2_2 = {}
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3, L23_3
    L1_3 = {}
    L2_3 = B_SERVICE
    L2_3 = L2_3.Embed
    L2_3 = L2_3()
    L2_3.description = ""
    L3_3 = pairs
    L4_3 = A0_3
    L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
    for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
      L9_3 = L8_3.identifier
      L10_3 = L8_3.kills
      L11_3 = L8_3.deaths
      L12_3 = L8_3.firstname
      L13_3 = " "
      L14_3 = L8_3.lastname
      L12_3 = L12_3 .. L13_3 .. L14_3
      L13_3 = L2_3.description
      L14_3 = [[

**#]]
      L15_3 = L7_3
      L16_3 = "** "
      L17_3 = L12_3
      L18_3 = " | Kills: "
      L19_3 = L10_3
      L20_3 = " | KD: "
      L21_3 = string
      L21_3 = L21_3.format
      L22_3 = "%.1f"
      L23_3 = L10_3 / L11_3
      L21_3 = L21_3(L22_3, L23_3)
      L13_3 = L13_3 .. L14_3 .. L15_3 .. L16_3 .. L17_3 .. L18_3 .. L19_3 .. L20_3 .. L21_3
      L2_3.description = L13_3
    end
    L3_3 = B_SERVICE
    L3_3 = L3_3.StatsWebhook
    if L3_3 then
      L3_3 = PerformHttpRequest
      L4_3 = B_SERVICE
      L4_3 = L4_3.StatsWebhook
      function L5_3(A0_4, A1_4, A2_4)
        local L3_4, L4_4, L5_4
        if 200 ~= A0_4 then
          L3_4 = print
          L4_4 = "b-ffa:sendStatsWebhook: errorCode: "
          L5_4 = A0_4
          L4_4 = L4_4 .. L5_4
          L3_4(L4_4)
        end
      end
      L6_3 = "POST"
      L7_3 = json
      L7_3 = L7_3.encode
      L8_3 = {}
      L9_3 = B_SERVICE
      L9_3 = L9_3.StatsWebhookName
      L8_3.username = L9_3
      L9_3 = {}
      L10_3 = L2_3
      L9_3[1] = L10_3
      L8_3.embeds = L9_3
      L7_3 = L7_3(L8_3)
      L8_3 = {}
      L8_3["Content-Type"] = "application/json"
      L3_3(L4_3, L5_3, L6_3, L7_3, L8_3)
    end
  end
  L0_2(L1_2, L2_2, L3_2)
end
sendStatsWebhook = L3_1
L3_1 = B_SERVICE
function L4_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L5_2 = TriggerClientEvent
  L6_2 = "b-ffa:sendNotify"
  L7_2 = A0_2
  L8_2 = A1_2
  L9_2 = A2_2
  L10_2 = A3_2
  L11_2 = A4_2
  L5_2(L6_2, L7_2, L8_2, L9_2, L10_2, L11_2)
end
L3_1.SendNotify = L4_1
L3_1 = RegisterNetEvent
L4_1 = "b-ffa:joinFFA"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L1_2 = source
  L2_2 = ESX
  L2_2 = L2_2.GetPlayerFromId
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    return
  end
  L3_2 = L2_2.getLoadout
  L3_2 = L3_2()
  L3_2 = #L3_2
  if L3_2 > 0 then
    L3_2 = L2_2.showNotification
    L4_2 = "Leg deine Waffen ab bevor du ins FFA kannst."
    L3_2(L4_2)
    return
  end
  L3_2 = A0_2.zoneId
  L4_2 = A0_2.password
  L5_2 = L0_1
  L5_2 = L5_2[L1_2]
  if L5_2 then
    L5_2 = L0_1
    L5_2 = L5_2[L1_2]
    L6_2 = GetGameTimer
    L6_2 = L6_2()
    if L5_2 > L6_2 then
      L5_2 = B_SERVICE
      L5_2 = L5_2.SendNotify
      L6_2 = L1_2
      L7_2 = "error"
      L8_2 = "FFA"
      L9_2 = "Anti Spam: Bitte warte 3 Sekunden"
      L10_2 = 5000
      return L5_2(L6_2, L7_2, L8_2, L9_2, L10_2)
    end
  end
  L5_2 = L0_1
  L6_2 = GetGameTimer
  L6_2 = L6_2()
  L6_2 = L6_2 + 3000
  L5_2[L1_2] = L6_2
  if not L4_2 then
    L5_2 = print
    L6_2 = "b-ffa:joinFFA: password is nil"
    return L5_2(L6_2)
  end
  L5_2 = type
  L6_2 = L4_2
  L5_2 = L5_2(L6_2)
  if "string" ~= L5_2 then
    L5_2 = print
    L6_2 = "b-ffa:joinFFA: password is not a string"
    return L5_2(L6_2)
  end
  if not L3_2 then
    L5_2 = print
    L6_2 = "b-ffa:joinFFA: zoneId is nil"
    return L5_2(L6_2)
  end
  L5_2 = type
  L6_2 = L3_2
  L5_2 = L5_2(L6_2)
  if "number" ~= L5_2 then
    L5_2 = print
    L6_2 = "b-ffa:joinFFA: zoneId is not a number"
    return L5_2(L6_2)
  end
  L5_2 = ESX
  L5_2 = L5_2.GetPlayerFromId
  L6_2 = L1_2
  L5_2 = L5_2(L6_2)
  if not L5_2 then
    L6_2 = print
    L7_2 = "b-ffa:joinFFA: xPlayer is nil"
    return L6_2(L7_2)
  end
  L6_2 = FFAPlayer
  L6_2 = L6_2.getPlayerFromIdentifier
  L7_2 = L5_2.getIdentifier
  L7_2, L8_2, L9_2, L10_2, L11_2, L12_2 = L7_2()
  L6_2 = L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  if not L6_2 then
    L7_2 = print
    L8_2 = "b-ffa:joinFFA: FPlayer is nil"
    L7_2(L8_2)
    L7_2 = FFAPlayer
    L7_2 = L7_2.new
    L8_2 = L5_2.source
    L9_2 = L5_2.getIdentifier
    L9_2, L10_2, L11_2, L12_2 = L9_2()
    L7_2 = L7_2(L8_2, L9_2, L10_2, L11_2, L12_2)
    L6_2 = L7_2
  end
  L7_2 = L6_2.inFFA
  L7_2 = L7_2()
  if L7_2 then
    L7_2 = L6_2.sendNotification
    L8_2 = "error"
    L9_2 = "FFA"
    L10_2 = "Du bist bereits in FFA"
    L11_2 = 5000
    return L7_2(L8_2, L9_2, L10_2, L11_2)
  end
  L7_2 = DoesEntityExist
  L8_2 = GetPlayerPed
  L9_2 = L1_2
  L8_2, L9_2, L10_2, L11_2, L12_2 = L8_2(L9_2)
  L7_2 = L7_2(L8_2, L9_2, L10_2, L11_2, L12_2)
  if not L7_2 then
    L7_2 = L6_2.sendNotification
    L8_2 = "error"
    L9_2 = "FFA"
    L10_2 = "Du bist tot"
    L11_2 = 5000
    return L7_2(L8_2, L9_2, L10_2, L11_2)
  end
  L7_2 = Zone
  L7_2 = L7_2.getZoneById
  L8_2 = L3_2
  L7_2 = L7_2(L8_2)
  L8_2 = L7_2.getType
  L8_2 = L8_2()
  L9_2 = ZoneType
  L9_2 = L9_2.STANDARD
  if L8_2 == L9_2 then
    L8_2 = L6_2.joinZone
    L9_2 = L5_2
    L10_2 = L7_2.getId
    L10_2, L11_2, L12_2 = L10_2()
    L8_2(L9_2, L10_2, L11_2, L12_2)
  else
    L8_2 = L7_2.getType
    L8_2 = L8_2()
    L9_2 = ZoneType
    L9_2 = L9_2.CUSTOM
    if L8_2 == L9_2 then
      L8_2 = L7_2.checkPassword
      L9_2 = L4_2
      L8_2 = L8_2(L9_2)
      if L8_2 then
        L8_2 = L6_2.joinZone
        L9_2 = L5_2
        L10_2 = L7_2.getId
        L10_2, L11_2, L12_2 = L10_2()
        L8_2(L9_2, L10_2, L11_2, L12_2)
      else
        L8_2 = L6_2.sendNotification
        L9_2 = "error"
        L10_2 = "FFA"
        L11_2 = "Falsches Passwort"
        L12_2 = 5000
        L8_2(L9_2, L10_2, L11_2, L12_2)
      end
    end
  end
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "b-ffa:quitFFA"
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L0_2 = source
  L1_2 = ESX
  L1_2 = L1_2.GetPlayerFromId
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  L2_2 = DoesEntityExist
  L3_2 = GetPlayerPed
  L4_2 = L0_2
  L3_2, L4_2, L5_2, L6_2, L7_2, L8_2 = L3_2(L4_2)
  L2_2 = L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2)
  if not L2_2 then
    L2_2 = B_SERVICE
    L2_2 = L2_2.SendNotify
    L3_2 = L1_2.source
    L4_2 = "error"
    L5_2 = "FFA"
    L6_2 = "Du bist tot"
    L7_2 = 5000
    return L2_2(L3_2, L4_2, L5_2, L6_2, L7_2)
  end
  if not L1_2 then
    L2_2 = print
    L3_2 = "b-ffa:quitFFA: xPlayer is nil"
    return L2_2(L3_2)
  end
  L2_2 = FFAPlayer
  L2_2 = L2_2.getPlayerFromIdentifier
  L3_2 = L1_2.getIdentifier
  L3_2, L4_2, L5_2, L6_2, L7_2, L8_2 = L3_2()
  L2_2 = L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2)
  if not L2_2 then
    L3_2 = B_SERVICE
    L3_2 = L3_2.SendNotify
    L4_2 = L1_2.source
    L5_2 = "error"
    L6_2 = "FFA"
    L7_2 = "Du bist nicht in FFA"
    L8_2 = 5000
    return L3_2(L4_2, L5_2, L6_2, L7_2, L8_2)
  end
  L4_2 = L1_2.source
  L3_2 = L0_1
  L3_2 = L3_2[L4_2]
  if L3_2 then
    L4_2 = L1_2.source
    L3_2 = L0_1
    L3_2 = L3_2[L4_2]
    L4_2 = GetGameTimer
    L4_2 = L4_2()
    if L3_2 > L4_2 then
      L3_2 = B_SERVICE
      L3_2 = L3_2.SendNotify
      L4_2 = L1_2.source
      L5_2 = "error"
      L6_2 = "FFA"
      L7_2 = "Anti Spam: Bitte warte 3 Sekunden"
      L8_2 = 5000
      return L3_2(L4_2, L5_2, L6_2, L7_2, L8_2)
    end
  end
  L4_2 = L1_2.source
  L3_2 = L0_1
  L5_2 = GetGameTimer
  L5_2 = L5_2()
  L5_2 = L5_2 + 3000
  L3_2[L4_2] = L5_2
  L3_2 = L2_2.quitZone
  L4_2 = L1_2
  L3_2(L4_2)
end
L3_1(L4_1, L5_1)
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  if not A0_2 then
    return
  end
  L1_2 = ipairs
  L2_2 = B_SERVICE
  L2_2 = L2_2.Zones
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    L7_2 = L6_2.name
    if L7_2 == A0_2 then
      return L6_2
    end
  end
end
GetMapByName = L3_1
L3_1 = RegisterNetEvent
L4_1 = "b-ffa:createFFA"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2
  L1_2 = source
  L2_2 = ESX
  L2_2 = L2_2.GetPlayerFromId
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    L3_2 = print
    L4_2 = "b-ffa:createFFA: xPlayer is nil"
    return L3_2(L4_2)
  end
  L3_2 = L2_2.getLoadout
  L3_2 = L3_2()
  L3_2 = #L3_2
  if L3_2 > 0 then
    L3_2 = L2_2.showNotification
    L4_2 = "Leg deine Waffen ab bevor du ins FFA kannst."
    L3_2(L4_2)
    return
  end
  L3_2 = FFAPlayer
  L3_2 = L3_2.getPlayerFromIdentifier
  L4_2 = L2_2.getIdentifier
  L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2 = L4_2()
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
  if not L3_2 then
    L4_2 = print
    L5_2 = "b-ffa:joinFFA: FPlayer is nil"
    L4_2(L5_2)
    L4_2 = FFAPlayer
    L4_2 = L4_2.new
    L5_2 = L2_2.source
    L6_2 = L2_2.getIdentifier
    L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2 = L6_2()
    L4_2 = L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
    L3_2 = L4_2
  end
  L4_2 = L3_2.inFFA
  L4_2 = L4_2()
  if L4_2 then
    L4_2 = L3_2.sendNotification
    L5_2 = "error"
    L6_2 = "FFA"
    L7_2 = "Du bist bereits in FFA"
    L8_2 = 5000
    return L4_2(L5_2, L6_2, L7_2, L8_2)
  end
  if not A0_2 then
    L4_2 = print
    L5_2 = "b-ffa:createFFA: data is nil"
    return L4_2(L5_2)
  end
  L4_2 = type
  L5_2 = A0_2
  L4_2 = L4_2(L5_2)
  if "table" ~= L4_2 then
    L4_2 = print
    L5_2 = "b-ffa:createFFA: data is not a table"
    return L4_2(L5_2)
  end
  L4_2 = A0_2.name
  if not L4_2 then
    L4_2 = print
    L5_2 = "b-ffa:createFFA: data.name is nil"
    return L4_2(L5_2)
  end
  L4_2 = type
  L5_2 = A0_2.name
  L4_2 = L4_2(L5_2)
  if "string" ~= L4_2 then
    L4_2 = print
    L5_2 = "b-ffa:createFFA: data.name is not a string"
    return L4_2(L5_2)
  end
  L4_2 = A0_2.password
  if not L4_2 then
    L4_2 = print
    L5_2 = "b-ffa:createFFA: data.password is nil"
    return L4_2(L5_2)
  end
  L4_2 = type
  L5_2 = A0_2.password
  L4_2 = L4_2(L5_2)
  if "string" ~= L4_2 then
    L4_2 = print
    L5_2 = "b-ffa:createFFA: data.password is not a string"
    return L4_2(L5_2)
  end
  L4_2 = A0_2.name
  if not L4_2 then
    L4_2 = "Lobby von "
    L5_2 = GetPlayerName
    L6_2 = L1_2
    L5_2 = L5_2(L6_2)
    L4_2 = L4_2 .. L5_2
  end
  L5_2 = A0_2.weapons
  if not L5_2 then
    L5_2 = {}
  end
  L6_2 = A0_2.password
  if not L6_2 then
    L6_2 = ""
  end
  L7_2 = GetMapByName
  L8_2 = A0_2.map
  L7_2 = L7_2(L8_2)
  if not L7_2 then
    L7_2 = B_SERVICE
    L7_2 = L7_2.Zones
    L7_2 = L7_2[1]
    L7_2 = L7_2.name
  end
  L8_2 = {}
  L9_2 = ipairs
  L10_2 = L5_2
  L9_2, L10_2, L11_2, L12_2 = L9_2(L10_2)
  for L13_2, L14_2 in L9_2, L10_2, L11_2, L12_2 do
    L15_2 = print
    L16_2 = L14_2
    L17_2 = ESX
    L17_2 = L17_2.GetWeaponLabel
    L18_2 = L14_2
    L17_2, L18_2, L19_2, L20_2, L21_2 = L17_2(L18_2)
    L15_2(L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
    L15_2 = ESX
    L15_2 = L15_2.GetWeaponLabel
    L16_2 = L14_2
    L15_2 = L15_2(L16_2)
    L8_2[L15_2] = L14_2
  end
  L9_2 = Zone
  L9_2 = L9_2.getZoneByName
  L10_2 = L4_2
  L9_2 = L9_2(L10_2)
  if L9_2 then
    L10_2 = L3_2.sendNotification
    L11_2 = "error"
    L12_2 = "FFA"
    L13_2 = "Es existiert bereits eine Zone mit diesem Namen"
    L14_2 = 5000
    return L10_2(L11_2, L12_2, L13_2, L14_2)
  end
  L10_2 = Zone
  L10_2 = L10_2.new
  L11_2 = ZoneType
  L11_2 = L11_2.CUSTOM
  L12_2 = L4_2
  L13_2 = L7_2.position
  L14_2 = L7_2.size
  L15_2 = L7_2.maxPlayers
  L16_2 = L7_2.gunType
  L17_2 = L8_2
  L18_2 = L7_2.image
  L19_2 = L7_2.spawnPoints
  L20_2 = L7_2.name
  L21_2 = L6_2
  L10_2 = L10_2(L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
  L11_2 = GlobalState
  L11_2 = L11_2.ffaZones
  if not L11_2 then
    L11_2 = {}
  end
  L12_2 = ipairs
  L13_2 = L11_2
  L12_2, L13_2, L14_2, L15_2 = L12_2(L13_2)
  for L16_2, L17_2 in L12_2, L13_2, L14_2, L15_2 do
    L18_2 = L17_2.getId
    L18_2 = L18_2()
    L19_2 = L10_2.getId
    L19_2 = L19_2()
    if L18_2 == L19_2 then
      return
    end
  end
  L12_2 = GlobalState
  L12_2.ffaZones = L11_2
  L12_2 = L3_2.joinZone
  L13_2 = L2_2
  L14_2 = L10_2.getId
  L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2 = L14_2()
  L12_2(L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "esx:onPlayerDeath"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L1_2 = source
  L2_2 = ESX
  L2_2 = L2_2.GetPlayerFromId
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    return
  end
  L3_2 = FFAPlayer
  L3_2 = L3_2.getPlayerFromIdentifier
  L4_2 = L2_2.getIdentifier
  L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2 = L4_2()
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2)
  if not L3_2 then
    return
  end
  L4_2 = L3_2.inFFA
  L4_2 = L4_2()
  if not L4_2 then
    return
  end
  L4_2 = A0_2.killedByPlayer
  if L4_2 then
    L4_2 = ESX
    L4_2 = L4_2.GetPlayerFromId
    L5_2 = A0_2.killerServerId
    L4_2 = L4_2(L5_2)
    if not L4_2 then
      return
    end
    L5_2 = FFAPlayer
    L5_2 = L5_2.getPlayerFromIdentifier
    L6_2 = L4_2.getIdentifier
    L6_2, L7_2, L8_2, L9_2, L10_2, L11_2 = L6_2()
    L5_2 = L5_2(L6_2, L7_2, L8_2, L9_2, L10_2, L11_2)
    if not L5_2 then
      return
    end
    L6_2 = L5_2.inFFA
    L6_2 = L6_2()
    if not L6_2 then
      return
    end
    L6_2 = L5_2.addKill
    L6_2()
    L6_2 = L3_2.addDeath
    L6_2()
    L6_2 = L5_2.refillAmmo
    L7_2 = L4_2
    L6_2(L7_2)
    L6_2 = L3_2.refillAmmo
    L7_2 = L2_2
    L6_2(L7_2)
    L6_2 = L3_2.sendNotification
    L7_2 = "success"
    L8_2 = "FFA"
    L9_2 = string
    L9_2 = L9_2.format
    L10_2 = "Du wurdest von %s get\195\182tet"
    L11_2 = L5_2.getName
    L11_2 = L11_2()
    L9_2 = L9_2(L10_2, L11_2)
    L10_2 = 5000
    L6_2(L7_2, L8_2, L9_2, L10_2)
    L6_2 = L5_2.sendNotification
    L7_2 = "success"
    L8_2 = "FFA"
    L9_2 = string
    L9_2 = L9_2.format
    L10_2 = "Du hast %s get\195\182tet"
    L11_2 = L3_2.getName
    L11_2 = L11_2()
    L9_2 = L9_2(L10_2, L11_2)
    L10_2 = 5000
    L6_2(L7_2, L8_2, L9_2, L10_2)
  else
    L4_2 = L3_2.addDeath
    L4_2()
    L4_2 = L3_2.refillAmmo
    L5_2 = L2_2
    L4_2(L5_2)
    L4_2 = L3_2.sendNotification
    L5_2 = "success"
    L6_2 = "FFA"
    L7_2 = "Du bist gestorben"
    L8_2 = 5000
    L4_2(L5_2, L6_2, L7_2, L8_2)
  end
end
L3_1(L4_1, L5_1)
L3_1 = AddEventHandler
L4_1 = "playerDropped"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L1_2 = source
  L2_2 = ESX
  L2_2 = L2_2.GetPlayerFromId
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  L3_2 = Player
  L4_2 = L1_2
  L3_2 = L3_2(L4_2)
  L3_2 = L3_2.state
  L3_2 = L3_2.ffaEntered
  if not L2_2 then
    L4_2 = print
    L5_2 = "Failed to drop Player in FFA"
    return L4_2(L5_2)
  end
  L4_2 = FFAPlayer
  L4_2 = L4_2.getPlayerFromIdentifier
  L5_2 = L2_2.identifier
  L4_2 = L4_2(L5_2)
  if L3_2 then
    L5_2 = Wait
    L6_2 = 5000
    L5_2(L6_2)
    L5_2 = MySQL
    L5_2 = L5_2.Sync
    L5_2 = L5_2.execute
    L6_2 = "UPDATE users SET loadout = @loadout, position = @position WHERE identifier = @identifier"
    L7_2 = {}
    L8_2 = L2_2.identifier
    L7_2["@identifier"] = L8_2
    L8_2 = json
    L8_2 = L8_2.encode
    L9_2 = {}
    L8_2 = L8_2(L9_2)
    L7_2["@loadout"] = L8_2
    L8_2 = json
    L8_2 = L8_2.encode
    L9_2 = {}
    L10_2 = B_SERVICE
    L10_2 = L10_2.EnterPositions
    L10_2 = L10_2[1]
    L10_2 = L10_2.position
    L10_2 = L10_2.x
    L9_2.x = L10_2
    L10_2 = B_SERVICE
    L10_2 = L10_2.EnterPositions
    L10_2 = L10_2[1]
    L10_2 = L10_2.position
    L10_2 = L10_2.y
    L9_2.y = L10_2
    L10_2 = B_SERVICE
    L10_2 = L10_2.EnterPositions
    L10_2 = L10_2[1]
    L10_2 = L10_2.position
    L10_2 = L10_2.z
    L9_2.z = L10_2
    L10_2 = B_SERVICE
    L10_2 = L10_2.EnterPositions
    L10_2 = L10_2[1]
    L10_2 = L10_2.position
    L10_2 = L10_2.w
    L9_2.heading = L10_2
    L8_2 = L8_2(L9_2)
    L7_2["@position"] = L8_2
    L5_2(L6_2, L7_2)
  end
  if L4_2 then
    L5_2 = L4_2.clearLoadout
    L6_2 = L2_2
    L5_2(L6_2)
    L5_2 = L4_2.getZone
    L5_2 = L5_2()
    L5_2 = L5_2.removePlayerCount
    L5_2()
    L5_2 = FFAPlayer
    L5_2 = L5_2.players
    L6_2 = L2_2.identifier
    L5_2[L6_2] = nil
  end
end
L3_1(L4_1, L5_1)
