B_SERVICE = {}

B_SERVICE.DrawDistance = 20.0

B_SERVICE.ReviveTrigger = 'esx_ambulancejob:revive'

B_SERVICE.SharedObject = {
    ["Client"] = "esx:getSharedObject",
    ["Server"] = "esx:getSharedObject",
}

B_SERVICE.Layout = {
    Title = "BERLIN CITY",
    Subtitle = "FFA SYSTEM",
}

B_SERVICE.EnterPositions = {
    {
        position = vector4(-265.3985, -2017.8551, 29.1456, 228.3698),
        range = 3.0,
        npc = {
            enabled = true,
            model = "g_m_importexport_01",
        },
        blip = {
            enabled = true,
            sprite = 439,
            color = 46,
            scale = 1.0,
            name = "Arena",
        },
        marker = {
            enabled = false,
            type = 1,
            scale = vector3(1.0, 1.0, 1.0),
            color = vector3(255, 255, 255),
            alpha = 255,
        },
        sphere = {
            enabled = true,
            color = {r = 255, g = 0, b = 0},
            alpha = 0.5, -- from 0.1 to 1.0
        },
    }
}

B_SERVICE.ShowHelpNotify = function(msg)
    ESX.ShowHelpNotification(msg)
end

B_SERVICE.SendNotify = function (type, title, message, time)
    TriggerEvent("b_notify", type, title, message, time)
end

B_SERVICE.KillCam = true
