B_SERVICE.StartDimensionCount = 1000 -- The start dimension count for the zones. Dynamic dimension count.

B_SERVICE.Custom = {
    DefaultMaxPlayers = 10, -- The default max players for custom zones.
}

B_SERVICE.StatsWebhook = "https://discord.com/api/webhooks/1117491244520706100/3KiU_EmvuP31FbozVDnTasmIp1c3wltUpuf0-rIWz1OEQH4gQCWo4JvDDi8popLneI99"
B_SERVICE.StatsWebhookName = "BerlinCity x FFA"

B_SERVICE.Embed = function()
    local embeds = {
        ["author"] = {
            ["name"] = "[FFA] BerlinCity",
            ["icon_url"] = "https://cdn.discordapp.com/attachments/947585488036986920/1117489727881363486/logoanimation_500x500_1.gif",
            ["url"] = "https://discord.gg/berlincity"
        },
        ["title"] = 'Top #10',
        ["color"] = 16711680,
        ["footer"] = {
            ["text"] = "BerlinCity FFA",
            ["icon_url"] = "https://cdn.discordapp.com/attachments/947585488036986920/1117489727881363486/logoanimation_500x500_1.gif",
        },
        ["timestamp"] = os.date('!%Y-%m-%dT%H:%M:%S'),
    }

    return embeds
end

B_SERVICE.Zones = {
    {
        type = "standard",
        name = "Marktplatz",
        position = vector3(383.8309, -339.3008, 46.8099),
        size = 60.0,
        maxPlayers = 20,
        gunType = "only Pistol",
        guns = {
            "WEAPON_PISTOL_MK2",
        },
        image = "https://bercity.eu/img/ffa/marktplatz.png",
        spawnPoints = {
            vector3(361.6491, -321.5237, 46.72794),
            vector3(360.1085, -326.1155, 46.70325),
            vector3(351.4258, -355.2146, 46.30766),
            vector3(377.9591, -373.5666, 46.91532),
            vector3(402.2596, -342.3023, 46.94073),
            vector3(432.7195, -328.4716, 47.15316),
            vector3(390.7364, -336.8633, 46.83396)
        }
    },
    {
        type = "standard",
        name = "Flugzeug Friedhof",
        position = vector3(2386.367, 3082.089, 48.19027),
        size = 100.0,
        maxPlayers = 20,
        gunType = "alle Waffen",
        guns = {
            "WEAPON_APPISTOL",
            "WEAPON_ADVANCEDRIFLE",
            "WEAPON_HEAVYRIFLE",
            "WEAPON_SPECIALCARBINE_MK2",
            "WEAPON_SNSPISTOL_MK2",
            "WEAPON_HEAVYPISTOL",
            "WEAPON_PISTOL_MK2",
            "WEAPON_ASSAULTRIFLE_MK2",
            "WEAPON_SNIPERRIFLE",
            "WEAPON_HEAVYSNIPER",
            "WEAPON_MARKSMANRIFLE",
            "WEAPON_BOTTLE",
            "WEAPON_BATTLEAXE",
            "WEAPON_GOLFCLUB",
            "WEAPON_HAMMER",
            "WEAPON_BULLPUPRIFLE_MK2",
            "WEAPON_PUMPSHOTGUN",
            "WEAPON_BULLPUPSHOTGUN",
            "WEAPON_HEAVYSHOTGUN",
            "WEAPON_DBSHOTGUN"
        },
        image = "https://bercity.eu/img/ffa/flugzeug.png",
        spawnPoints = {
            vector3(2360.073, 3129.041, 48.20869),
            vector3(2428.039, 3124.009, 48.14234),
            vector3(2428.231, 3087.216, 48.43743),
            vector3(2409.702, 3033.869, 48.16072),
            vector3(2355.944, 3038.585, 48.16628),
            vector3(2394.191, 3109.82, 48.18212)
        }
    },
    {
        type = "standard",
        name = "Baustelle",
        position = vector3(-160.0956, -983.2939, 256.2072),
        size = 100.0,
        maxPlayers = 20,
        gunType = "only Pistol",
        guns = {
            "WEAPON_PISTOL_MK2",
        },
        image = "https://bercity.eu/img/ffa/baustelle.png", 
        spawnPoints = {
            vector3(-144.4777, -985.3557, 254.1313),
            vector3(-187.9534, -1010.627, 254.3566),
            vector3(-152.8695, -945.8582, 254.1313),
            vector3(-151.9951, -976.306, 269.1091),
            vector3(-146.3017, -949.2743, 269.1355),
            vector3(-146.5233, -950.3701, 259.1329)
        }
    },
    {
        type = "standard",
        name = "Museum",
        position = vector3(-2246.32, 273.79, 174.6),
        size = 100.0,
        maxPlayers = 20,
        gunType = "only Sturmgewehr",
        guns = {
            "WEAPON_ADVANCEDRIFLE",
            "WEAPON_HEAVYRIFLE",
            "WEAPON_SPECIALCARBINE_MK2",
            "WEAPON_ASSAULTRIFLE_MK2",
            "WEAPON_BULLPUPRIFLE_MK2"
        },
        image = "https://bercity.eu/img/ffa/museum.png", 
        spawnPoints = {
            vector3(-2253.6973, 236.4215, 174.6071),
            vector3(-2225.1250, 302.3777, 174.6017),
            vector3(-2231.6875, 331.2343, 174.6019),
            vector3(-2263.0835, 349.1236, 174.6019),
            vector3(-2256.8552, 321.3572, 184.5869),
            vector3(-2204.2722, 215.3658, 184.6017)
        }
    },
    {
        type = "standard",
        name = "FIB Dach",
        position = vector3(136.21, -734.86, 262.85),
        size = 50.0,
        maxPlayers = 20,
        gunType = "only Sniper",
        guns = {
            "WEAPON_SNIPERRIFLE",
            "WEAPON_HEAVYSNIPER",
            "WEAPON_MARKSMANRIFLE"
        },
        image = "https://bercity.eu/img/ffa/fibdach.png", 
        spawnPoints = {
            vector3(118.25, -742.64, 262.85),
            vector3(131.66, -762.18, 262.82),
            vector3(151.25, -754.94, 262.85)
        }
    },
    {
        type = "standard",
        name = "CASINO Dach",
        position = vector3(932.7, 39.51, 114.36),
        size = 50.0,
        maxPlayers = 20,
        gunType = "ONE IN THE CHAMBER",
        guns = {
            "WEAPON_MARKSMANPISTOL"
        },
        image = "https://bercity.eu/img/ffa/casinodach1.png", 
        spawnPoints = {
            vector3(911.3515, 52.2554, 111.7010),
            vector3(956.5032, 78.7571, 111.3268),
            vector3(957.5261, 49.8627, 112.5533),
            vector3(907.1877, 8.9742, 111.2714),
            vector3(933.6746, 1.4421, 111.2873)
        }
    },
    {
        type = "standard",
        name = "DORF",
        position = vector3(-1109.7399, 4923.4814, 217.5019),
        size = 100.0,
        maxPlayers = 20,
        gunType = "only nahkampf",
        guns = {
            "WEAPON_BOTTLE",
            "WEAPON_BATTLEAXE",
            "WEAPON_GOLFCLUB",
            "WEAPON_HAMMER"
        },
        image = "https://bercity.eu/img/ffa/dorf.png", 
        spawnPoints = {
            vector3(-1105.7543, 4960.3335, 218.5995),
            vector3(-1146.5032, 4938.7612, 222.2687),
            vector3(-1133.5409, 4903.5918, 219.4301),
            vector3(-1133.5409, 4903.5918, 219.4301),
            vector3(-1088.5675, 4881.4072, 216.0532),
            vector3(-1066.1489, 4916.4365, 212.8369),
            vector3(-1094.7650, 4943.4160, 218.3409)
        }
    },
    {
        type = "standard",
        name = "Crackhaus",
        position = vector3(2454.44, 4977.72, 46.81),
        size = 100.0,
        maxPlayers = 20,
        gunType = "only pumpgun",
        guns = {
            "WEAPON_PUMPSHOTGUN",
            "WEAPON_BULLPUPSHOTGUN",
            "WEAPON_HEAVYSHOTGUN",
            "WEAPON_DBSHOTGUN"
        },
        image = "https://bercity.eu/img/ffa/crackhaus.png", 
        spawnPoints = {
            vector3(2436.94, 4958.85, 46.81),
            vector3(2436.71, 4967.5, 42.35),
            vector3(2440.63, 4985.39, 51.56),
            vector3(2443.21, 4976.4, 51.56),
            vector3(2442.14, 4985.49, 46.81)
        }
    }
}
