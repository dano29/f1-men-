local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1
L0_1 = false
L1_1 = nil
L2_1 = false
ESX = nil
L3_1 = Citizen
L3_1 = L3_1.CreateThread
function L4_1()
  local L0_2, L1_2, L2_2
  L0_2 = exports
  L0_2 = L0_2.es_extended
  L1_2 = L0_2
  L0_2 = L0_2.getSharedObject
  L0_2 = L0_2(L1_2)
  if L0_2 then
    L0_2 = exports
    L0_2 = L0_2.es_extended
    L1_2 = L0_2
    L0_2 = L0_2.getSharedObject
    L0_2 = L0_2(L1_2)
    ESX = L0_2
    L0_2 = print
    L1_2 = "ESX v2 found"
    L0_2(L1_2)
  else
    while true do
      L0_2 = ESX
      if nil ~= L0_2 then
        break
      end
      L0_2 = TriggerEvent
      L1_2 = B_SERVICE
      L1_2 = L1_2.SharedObject
      L1_2 = L1_2.Client
      function L2_2(A0_3)
        local L1_3
        ESX = A0_3
      end
      L0_2(L1_2, L2_2)
      L0_2 = Citizen
      L0_2 = L0_2.Wait
      L1_2 = 0
      L0_2(L1_2)
    end
    L0_2 = print
    L1_2 = "ESX v1 found"
    L0_2(L1_2)
  end
  L0_2 = Wait
  L1_2 = 2000
  L0_2(L1_2)
  L0_2 = TriggerServerEvent
  L1_2 = "b_ffa:getFFAZones"
  L0_2(L1_2)
end
L3_1(L4_1)
L3_1 = RegisterNetEvent
L4_1 = "b_ffa:setFFAZones"
function L5_1(A0_2)
  local L1_2
  L1_2 = GlobalState
  L1_2.ffaZones = A0_2
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "b-ffa:sendNotification"
function L5_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2
  L4_2 = B_SERVICE
  L4_2 = L4_2.SendNotify
  L5_2 = A0_2
  L6_2 = A1_2
  L7_2 = A2_2
  L8_2 = A3_2
  L4_2(L5_2, L6_2, L7_2, L8_2)
end
L3_1(L4_1, L5_1)
function L3_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  L0_2 = {}
  L1_2 = pairs
  L2_2 = GlobalState
  L2_2 = L2_2.ffaZones
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    L7_2 = pairs
    L8_2 = L6_2.guns
    L7_2, L8_2, L9_2, L10_2 = L7_2(L8_2)
    for L11_2, L12_2 in L7_2, L8_2, L9_2, L10_2 do
      L13_2 = ESX
      L13_2 = L13_2.GetWeaponLabel
      L14_2 = L12_2
      L13_2 = L13_2(L14_2)
      L0_2[L12_2] = L13_2
    end
  end
  return L0_2
end
getWeaponOptions = L3_1
function L3_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L0_2 = {}
  L1_2 = pairs
  L2_2 = GlobalState
  L2_2 = L2_2.ffaZones
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    L7_2 = L6_2.id
    L8_2 = L6_2.name
    L0_2[L7_2] = L8_2
  end
  return L0_2
end
getMapOptions = L3_1
L3_1 = Citizen
L3_1 = L3_1.CreateThread
function L4_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  while true do
    L0_2 = GlobalState
    L0_2 = L0_2.ffaZones
    if nil ~= L0_2 then
      break
    end
    L0_2 = print
    L1_2 = json
    L1_2 = L1_2.encode
    L2_2 = GlobalState
    L2_2 = L2_2.ffaZones
    L1_2, L2_2, L3_2, L4_2, L5_2 = L1_2(L2_2)
    L0_2(L1_2, L2_2, L3_2, L4_2, L5_2)
    L0_2 = print
    L1_2 = "Waiting for ffaZones to be loaded"
    L0_2(L1_2)
    L0_2 = Wait
    L1_2 = 500
    L0_2(L1_2)
  end
  while true do
    L0_2 = L2_1
    if L0_2 then
      break
    end
    L0_2 = print
    L1_2 = "Wait for NUI"
    L0_2(L1_2)
    L0_2 = Wait
    L1_2 = 1000
    L0_2(L1_2)
  end
  L0_2 = print
  L1_2 = "Loading"
  L0_2(L1_2)
  L0_2 = getWeaponOptions
  L0_2 = L0_2()
  L1_2 = getMapOptions
  L1_2 = L1_2()
  L2_2 = SendNUIMessage
  L3_2 = {}
  L3_2.type = "sendData"
  L4_2 = json
  L4_2 = L4_2.encode
  L5_2 = B_SERVICE
  L5_2 = L5_2.Layout
  L4_2 = L4_2(L5_2)
  L3_2.layoutSettings = L4_2
  L4_2 = json
  L4_2 = L4_2.encode
  L5_2 = L0_2
  L4_2 = L4_2(L5_2)
  L3_2.weaponOptions = L4_2
  L4_2 = json
  L4_2 = L4_2.encode
  L5_2 = L1_2
  L4_2 = L4_2(L5_2)
  L3_2.mapOptions = L4_2
  L2_2(L3_2)
  L2_2 = print
  L3_2 = "FFA Zones loaded"
  L2_2(L3_2)
end
L3_1(L4_1)
L3_1 = AddStateBagChangeHandler
L4_1 = "ffaZones"
L5_1 = nil
function L6_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2
  L3_2 = print
  L4_2 = A0_2
  L5_2 = A1_2
  L6_2 = A2_2
  L3_2(L4_2, L5_2, L6_2)
  if "global" == A0_2 and "ffaZones" == A1_2 then
    L3_2 = SendNUIMessage
    L4_2 = {}
    L4_2.type = "ffaData"
    L5_2 = json
    L5_2 = L5_2.encode
    L6_2 = A2_2
    L5_2 = L5_2(L6_2)
    L4_2.data = L5_2
    L3_2(L4_2)
  end
end
L3_1(L4_1, L5_1, L6_1)
function L3_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = {}
  L2_2.deaths = 0
  L2_2.kills = 0
  if "ffaDeaths" == A0_2 then
    L2_2.deaths = A1_2
    L3_2 = LocalPlayer
    L3_2 = L3_2.state
    L3_2 = L3_2.ffaKills
    if not L3_2 then
      L3_2 = 0
    end
    L2_2.kills = L3_2
  elseif "ffaKills" == A0_2 then
    L3_2 = SetEntityHealth
    L4_2 = PlayerPedId
    L4_2 = L4_2()
    L5_2 = GetEntityMaxHealth
    L6_2 = PlayerPedId
    L6_2 = L6_2()
    L5_2, L6_2 = L5_2(L6_2)
    L3_2(L4_2, L5_2, L6_2)
    L3_2 = SetPedArmour
    L4_2 = PlayerPedId
    L4_2 = L4_2()
    L5_2 = 100
    L3_2(L4_2, L5_2)
    L2_2.kills = A1_2
    L3_2 = LocalPlayer
    L3_2 = L3_2.state
    L3_2 = L3_2.ffaDeaths
    if not L3_2 then
      L3_2 = 0
    end
    L2_2.deaths = L3_2
  else
    L3_2 = LocalPlayer
    L3_2 = L3_2.state
    L3_2 = L3_2.ffaDeaths
    L2_2.deaths = L3_2
    L3_2 = LocalPlayer
    L3_2 = L3_2.state
    L3_2 = L3_2.ffaKills
    L2_2.kills = L3_2
  end
  L3_2 = SendNUIMessage
  L4_2 = {}
  L4_2.type = "statsData"
  L5_2 = json
  L5_2 = L5_2.encode
  L6_2 = L2_2
  L5_2 = L5_2(L6_2)
  L4_2.data = L5_2
  L3_2(L4_2)
end
UpdateStats = L3_1
L3_1 = RegisterNetEvent
L4_1 = "b-ffa:enteredFFA"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = A0_2.type
  if "custom" ~= L1_2 then
    L1_2 = SendNUIMessage
    L2_2 = {}
    L2_2.type = "toggleStats"
    L2_2.display = true
    L1_2(L2_2)
  end
  L1_2 = RenderSphere
  L2_2 = A0_2
  L1_2(L2_2)
  L1_2 = UpdateStats
  L1_2()
  L1_2 = GetEntityMaxHealth
  L2_2 = PlayerPedId
  L2_2, L3_2, L4_2 = L2_2()
  L1_2 = L1_2(L2_2, L3_2, L4_2)
  L2_2 = SetEntityHealth
  L3_2 = PlayerPedId
  L3_2 = L3_2()
  L4_2 = L1_2
  L2_2(L3_2, L4_2)
  L2_2 = SetPedArmour
  L3_2 = PlayerPedId
  L3_2 = L3_2()
  L4_2 = 100
  L2_2(L3_2, L4_2)
  L2_2 = Citizen
  L2_2 = L2_2.CreateThread
  function L3_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3
    while true do
      L0_3 = LocalPlayer
      L0_3 = L0_3.state
      L0_3 = L0_3.ffaEntered
      if not L0_3 then
        break
      end
      L0_3 = Citizen
      L0_3 = L0_3.Wait
      L1_3 = 1000
      L0_3(L1_3)
      L0_3 = GetSelectedPedWeapon
      L1_3 = PlayerPedId
      L1_3, L2_3, L3_3, L4_3 = L1_3()
      L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3)
      L1_3 = SetPedAmmo
      L2_3 = PlayerPedId
      L2_3 = L2_3()
      L3_3 = L0_3
      L4_3 = 999
      L1_3(L2_3, L3_3, L4_3)
    end
  end
  L2_2(L3_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "b-ffa:leftFFA"
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = SendNUIMessage
  L1_2 = {}
  L1_2.type = "toggleStats"
  L1_2.display = false
  L0_2(L1_2)
  L0_2 = GetEntityCoords
  L1_2 = PlayerPedId
  L1_2, L2_2, L3_2, L4_2 = L1_2()
  L0_2 = L0_2(L1_2, L2_2, L3_2, L4_2)
  L1_2 = GetInteriorAtCoords
  L2_2 = L0_2.x
  L3_2 = L0_2.y
  L4_2 = L0_2.z
  L1_2 = L1_2(L2_2, L3_2, L4_2)
  L2_2 = RefreshInterior
  L3_2 = L1_2
  L2_2(L3_2)
  L2_2 = SetPedArmour
  L3_2 = PlayerPedId
  L3_2 = L3_2()
  L4_2 = 0
  L2_2(L3_2, L4_2)
end
L3_1(L4_1, L5_1)
L3_1 = AddStateBagChangeHandler
L4_1 = "ffaDeaths"
L5_1 = nil
function L6_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2
  L3_2 = GetPlayerFromStateBagName
  L4_2 = A0_2
  L3_2 = L3_2(L4_2)
  L4_2 = PlayerId
  L4_2 = L4_2()
  if L3_2 ~= L4_2 then
    return
  end
  L4_2 = UpdateStats
  L5_2 = A1_2
  L6_2 = A2_2
  L4_2(L5_2, L6_2)
end
L3_1(L4_1, L5_1, L6_1)
L3_1 = AddStateBagChangeHandler
L4_1 = "ffaKills"
L5_1 = nil
function L6_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2
  L3_2 = GetPlayerFromStateBagName
  L4_2 = A0_2
  L3_2 = L3_2(L4_2)
  L4_2 = PlayerId
  L4_2 = L4_2()
  if L3_2 ~= L4_2 then
    return
  end
  L4_2 = UpdateStats
  L5_2 = A1_2
  L6_2 = A2_2
  L4_2(L5_2, L6_2)
end
L3_1(L4_1, L5_1, L6_1)
L3_1 = RegisterNetEvent
L4_1 = "ffa:restock"
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = GetCurrentPedWeapon
  L1_2 = PlayerPedId
  L1_2, L2_2, L3_2, L4_2 = L1_2()
  L0_2 = L0_2(L1_2, L2_2, L3_2, L4_2)
  L1_2 = SetPedAmmo
  L2_2 = PlayerPedId
  L2_2 = L2_2()
  L3_2 = L0_2
  L4_2 = 999
  L1_2(L2_2, L3_2, L4_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "esx:onPlayerDeath"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L1_2 = LocalPlayer
  L1_2 = L1_2.state
  L1_2 = L1_2.ffaEntered
  if not L1_2 then
    return
  end
  L2_2 = A0_2.killedByPlayer
  if L2_2 then
    L2_2 = GetPlayerFromServerId
    L3_2 = A0_2.killerServerId
    L2_2 = L2_2(L3_2)
    L3_2 = GetPlayerPed
    L4_2 = L2_2
    L3_2 = L3_2(L4_2)
    L4_2 = GetPlayerPed
    L5_2 = -1
    L4_2 = L4_2(L5_2)
    L5_2 = B_SERVICE
    L5_2 = L5_2.KillCam
    if L5_2 then
      if L3_2 ~= L4_2 then
        L5_2 = true
        L0_1 = L5_2
        L5_2 = CreateCam
        L6_2 = "DEFAULT_SCRIPTED_CAMERA"
        L7_2 = true
        L5_2 = L5_2(L6_2, L7_2)
        L6_2 = SetCamActive
        L7_2 = L5_2
        L8_2 = true
        L6_2(L7_2, L8_2)
        L6_2 = RenderScriptCams
        L7_2 = true
        L8_2 = false
        L9_2 = 1000
        L10_2 = true
        L11_2 = true
        L6_2(L7_2, L8_2, L9_2, L10_2, L11_2)
        L6_2 = AttachCamToEntity
        L7_2 = L5_2
        L8_2 = L4_2
        L9_2 = 0.0
        L10_2 = 0.0
        L11_2 = -1.0
        L12_2 = true
        L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
        L6_2 = PointCamAtEntity
        L7_2 = L5_2
        L8_2 = L3_2
        L9_2 = 0.0
        L10_2 = 0.0
        L11_2 = 1.0
        L12_2 = true
        L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
        L6_2 = Citizen
        L6_2 = L6_2.CreateThread
        function L7_2()
          local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
          L0_3 = Citizen
          L0_3 = L0_3.Wait
          L1_3 = 3000
          L0_3(L1_3)
          L0_3 = false
          L0_1 = L0_3
          L0_3 = RenderScriptCams
          L1_3 = false
          L2_3 = false
          L3_3 = 0
          L4_3 = true
          L5_3 = true
          L0_3(L1_3, L2_3, L3_3, L4_3, L5_3)
          L0_3 = DestroyCam
          L1_3 = L5_2
          L2_3 = false
          L0_3(L1_3, L2_3)
          L0_3 = Revive
          L0_3()
        end
        L6_2(L7_2)
      end
    else
      L5_2 = Citizen
      L5_2 = L5_2.CreateThread
      function L6_2()
        local L0_3, L1_3, L2_3, L3_3
        L0_3 = Citizen
        L0_3 = L0_3.Wait
        L1_3 = 3000
        L0_3(L1_3)
        L0_3 = TriggerEvent
        L1_3 = "killed:ffa"
        L2_3 = L3_2
        L3_3 = A0_2.deathCause
        L0_3(L1_3, L2_3, L3_3)
        L0_3 = Revive
        L0_3()
      end
      L5_2(L6_2)
    end
  else
    L2_2 = Citizen
    L2_2 = L2_2.CreateThread
    function L3_2()
      local L0_3, L1_3
      L0_3 = Citizen
      L0_3 = L0_3.Wait
      L1_3 = 3000
      L0_3(L1_3)
      L0_3 = Revive
      L0_3()
    end
    L2_2(L3_2)
  end
end
L3_1(L4_1, L5_1)
function L3_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = LocalPlayer
  L0_2 = L0_2.state
  L0_2 = L0_2.ffaZoneId
  L1_2 = getFFADataById
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  L2_2 = spawnToRandomSpawnPoint
  L3_2 = L1_2
  L2_2(L3_2)
end
Revive = L3_1
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = ipairs
  L2_2 = GlobalState
  L2_2 = L2_2.ffaZones
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    if L5_2 == A0_2 then
      return L6_2
    end
  end
end
getFFADataById = L3_1
L3_1 = Citizen
L3_1 = L3_1.CreateThread
function L4_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L0_2 = ipairs
  L1_2 = B_SERVICE
  L1_2 = L1_2.EnterPositions
  L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
  for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
    L6_2 = L5_2.blip
    if L6_2 then
      L6_2 = L5_2.blip
      L6_2 = L6_2.enabled
      if L6_2 then
        L6_2 = L5_2.blip
        L7_2 = AddBlipForCoord
        L8_2 = L5_2.position
        L8_2 = L8_2.x
        L9_2 = L5_2.position
        L9_2 = L9_2.y
        L10_2 = L5_2.position
        L10_2 = L10_2.z
        L7_2 = L7_2(L8_2, L9_2, L10_2)
        L6_2.handle = L7_2
        L6_2 = SetBlipSprite
        L7_2 = L5_2.blip
        L7_2 = L7_2.handle
        L8_2 = L5_2.blip
        L8_2 = L8_2.sprite
        L6_2(L7_2, L8_2)
        L6_2 = SetBlipColour
        L7_2 = L5_2.blip
        L7_2 = L7_2.handle
        L8_2 = L5_2.blip
        L8_2 = L8_2.color
        L6_2(L7_2, L8_2)
        L6_2 = SetBlipScale
        L7_2 = L5_2.blip
        L7_2 = L7_2.handle
        L8_2 = L5_2.blip
        L8_2 = L8_2.scale
        L6_2(L7_2, L8_2)
        L6_2 = SetBlipAsShortRange
        L7_2 = L5_2.blip
        L7_2 = L7_2.handle
        L8_2 = true
        L6_2(L7_2, L8_2)
        L6_2 = BeginTextCommandSetBlipName
        L7_2 = "STRING"
        L6_2(L7_2)
        L6_2 = AddTextComponentString
        L7_2 = L5_2.blip
        L7_2 = L7_2.name
        L6_2(L7_2)
        L6_2 = EndTextCommandSetBlipName
        L7_2 = L5_2.blip
        L7_2 = L7_2.handle
        L6_2(L7_2)
      end
    end
  end
end
L3_1(L4_1)
L3_1 = Citizen
L3_1 = L3_1.CreateThread
function L4_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2
  while true do
    L0_2 = Citizen
    L0_2 = L0_2.Wait
    L1_2 = 0
    L0_2(L1_2)
    L0_2 = true
    L1_2 = LocalPlayer
    L1_2 = L1_2.state
    L1_2 = L1_2.ffaEntered
    if not L1_2 then
      L1_2 = PlayerPedId
      L1_2 = L1_2()
      L2_2 = GetEntityCoords
      L3_2 = L1_2
      L2_2 = L2_2(L3_2)
      L3_2 = ipairs
      L4_2 = B_SERVICE
      L4_2 = L4_2.EnterPositions
      L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
      for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
        L9_2 = vector3
        L10_2 = L8_2.position
        L10_2 = L10_2.x
        L11_2 = L8_2.position
        L11_2 = L11_2.y
        L12_2 = L8_2.position
        L12_2 = L12_2.z
        L9_2 = L9_2(L10_2, L11_2, L12_2)
        L9_2 = L2_2 - L9_2
        L9_2 = #L9_2
        L10_2 = B_SERVICE
        L10_2 = L10_2.DrawDistance
        if L9_2 <= L10_2 then
          L0_2 = false
          L10_2 = L8_2.npc
          if L10_2 then
            L10_2 = L8_2.npc
            L10_2 = L10_2.enabled
            if L10_2 then
              L10_2 = DoesEntityExist
              L11_2 = L8_2.npc
              L11_2 = L11_2.handle
              L10_2 = L10_2(L11_2)
              if not L10_2 then
                L10_2 = GetHashKey
                L11_2 = L8_2.npc
                L11_2 = L11_2.model
                L10_2 = L10_2(L11_2)
                L11_2 = RequestModel
                L12_2 = L10_2
                L11_2(L12_2)
                while true do
                  L11_2 = HasModelLoaded
                  L12_2 = L10_2
                  L11_2 = L11_2(L12_2)
                  if L11_2 then
                    break
                  end
                  L11_2 = Citizen
                  L11_2 = L11_2.Wait
                  L12_2 = 0
                  L11_2(L12_2)
                end
                L11_2 = L8_2.npc
                L12_2 = CreatePed
                L13_2 = 4
                L14_2 = L10_2
                L15_2 = L8_2.position
                L15_2 = L15_2.x
                L16_2 = L8_2.position
                L16_2 = L16_2.y
                L17_2 = L8_2.position
                L17_2 = L17_2.z
                L18_2 = L8_2.position
                L18_2 = L18_2.w
                L19_2 = false
                L20_2 = false
                L12_2 = L12_2(L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2)
                L11_2.handle = L12_2
                L11_2 = SetEntityAsMissionEntity
                L12_2 = L8_2.npc
                L12_2 = L12_2.handle
                L13_2 = true
                L14_2 = true
                L11_2(L12_2, L13_2, L14_2)
                L11_2 = SetPedCanRagdoll
                L12_2 = L8_2.npc
                L12_2 = L12_2.handle
                L13_2 = false
                L11_2(L12_2, L13_2)
                L11_2 = SetPedCanRagdollFromPlayerImpact
                L12_2 = L8_2.npc
                L12_2 = L12_2.handle
                L13_2 = false
                L11_2(L12_2, L13_2)
                L11_2 = SetEntityInvincible
                L12_2 = L8_2.npc
                L12_2 = L12_2.handle
                L13_2 = true
                L11_2(L12_2, L13_2)
                L11_2 = SetBlockingOfNonTemporaryEvents
                L12_2 = L8_2.npc
                L12_2 = L12_2.handle
                L13_2 = true
                L11_2(L12_2, L13_2)
                L11_2 = FreezeEntityPosition
                L12_2 = L8_2.npc
                L12_2 = L12_2.handle
                L13_2 = true
                L11_2(L12_2, L13_2)
              end
            end
          end
          L10_2 = L8_2.marker
          if L10_2 then
            L10_2 = L8_2.marker
            L10_2 = L10_2.enabled
            if L10_2 then
              L10_2 = DrawMarker
              L11_2 = L8_2.marker
              L11_2 = L11_2.type
              L12_2 = L8_2.position
              L12_2 = L12_2.x
              L13_2 = L8_2.position
              L13_2 = L13_2.y
              L14_2 = L8_2.position
              L14_2 = L14_2.z
              L15_2 = 0.0
              L16_2 = 0.0
              L17_2 = 0.0
              L18_2 = 0.0
              L19_2 = 0.0
              L20_2 = 0.0
              L21_2 = L8_2.marker
              L21_2 = L21_2.scale
              L21_2 = L21_2.x
              L22_2 = L8_2.marker
              L22_2 = L22_2.scale
              L22_2 = L22_2.y
              L23_2 = L8_2.marker
              L23_2 = L23_2.scale
              L23_2 = L23_2.z
              L24_2 = L8_2.marker
              L24_2 = L24_2.color
              L24_2 = L24_2.x
              L25_2 = L8_2.marker
              L25_2 = L25_2.color
              L25_2 = L25_2.y
              L26_2 = L8_2.marker
              L26_2 = L26_2.color
              L26_2 = L26_2.z
              L27_2 = L8_2.marker
              L27_2 = L27_2.alpha
              L28_2 = nil
              L29_2 = 2
              L30_2 = false
              L31_2 = false
              L32_2 = false
              L33_2 = false
              L10_2(L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2)
            end
          end
          L10_2 = L8_2.range
          if L9_2 <= L10_2 then
            L10_2 = B_SERVICE
            L10_2 = L10_2.ShowHelpNotify
            L11_2 = "Dr\195\188cke E um FFA beizutreten."
            L10_2(L11_2)
            L10_2 = IsControlJustReleased
            L11_2 = 0
            L12_2 = 38
            L10_2 = L10_2(L11_2, L12_2)
            if L10_2 then
              L10_2 = ShowFFA
              L10_2()
              L1_1 = L8_2
              L10_2 = Wait
              L11_2 = 0
              L10_2(L11_2)
            end
          end
        else
          L10_2 = L8_2.npc
          if L10_2 then
            L10_2 = L8_2.npc
            L10_2 = L10_2.enabled
            if L10_2 then
              L10_2 = DoesEntityExist
              L11_2 = L8_2.npc
              L11_2 = L11_2.handle
              L10_2 = L10_2(L11_2)
              if L10_2 then
                L10_2 = DeleteEntity
                L11_2 = L8_2.npc
                L11_2 = L11_2.handle
                L10_2(L11_2)
                L10_2 = L8_2.npc
                L10_2.handle = nil
              end
            end
          end
        end
      end
    end
    if L0_2 then
      L1_2 = Wait
      L2_2 = 1500
      L1_2(L2_2)
    end
  end
end
L3_1(L4_1)
function L3_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = SendNUIMessage
  L1_2 = {}
  L1_2.type = "ffaData"
  L2_2 = json
  L2_2 = L2_2.encode
  L3_2 = GlobalState
  L3_2 = L3_2.ffaZones
  L2_2 = L2_2(L3_2)
  L1_2.data = L2_2
  L0_2(L1_2)
  L0_2 = SendNUIMessage
  L1_2 = {}
  L1_2.type = "toggleDisplay"
  L1_2.display = true
  L0_2(L1_2)
  L0_2 = SetNuiFocus
  L1_2 = true
  L2_2 = true
  L0_2(L1_2, L2_2)
end
ShowFFA = L3_1
function L3_1()
  local L0_2, L1_2, L2_2
  L0_2 = SendNUIMessage
  L1_2 = {}
  L1_2.type = "toggleDisplay"
  L1_2.display = false
  L0_2(L1_2)
  L0_2 = SetNuiFocus
  L1_2 = false
  L2_2 = false
  L0_2(L1_2, L2_2)
end
Exit = L3_1
L3_1 = RegisterNUICallback
L4_1 = "ffa:exit"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = Exit
  L2_2()
  L2_2 = A1_2
  L3_2 = "ok"
  L2_2(L3_2)
end
L3_1(L4_1, L5_1)
function L3_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L2_2 = AddTextEntry
  L3_2 = "FFA_INPUT_TITLE"
  L4_2 = A0_2
  L2_2(L3_2, L4_2)
  L2_2 = DisplayOnscreenKeyboard
  L3_2 = 1
  L4_2 = "FFA_INPUT_TITLE"
  L5_2 = ""
  L6_2 = ""
  L7_2 = ""
  L8_2 = ""
  L9_2 = ""
  L10_2 = A1_2
  L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2)
  while true do
    L2_2 = UpdateOnscreenKeyboard
    L2_2 = L2_2()
    if 0 ~= L2_2 then
      break
    end
    L2_2 = Wait
    L3_2 = 0
    L2_2(L3_2)
  end
  L2_2 = UpdateOnscreenKeyboard
  L2_2 = L2_2()
  if 2 ~= L2_2 then
    L2_2 = GetOnscreenKeyboardResult
    L2_2 = L2_2()
    L3_2 = Wait
    L4_2 = 0
    L3_2(L4_2)
    return L2_2
  else
    L2_2 = Wait
    L3_2 = 0
    L2_2(L3_2)
    L2_2 = nil
    return L2_2
  end
end
getTextInput = L3_1
L3_1 = RegisterNUICallback
L4_1 = "ffa:join"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = Exit
  L2_2()
  A0_2.password = ""
  L2_2 = A0_2.type
  if "custom" == L2_2 then
    L2_2 = getTextInput
    L3_2 = "FFA Passwort"
    L4_2 = 20
    L2_2 = L2_2(L3_2, L4_2)
    A0_2.password = L2_2
    L3_2 = TriggerServerEvent
    L4_2 = "b-ffa:joinFFA"
    L5_2 = A0_2
    L3_2(L4_2, L5_2)
  else
    L2_2 = TriggerServerEvent
    L3_2 = "b-ffa:joinFFA"
    L4_2 = A0_2
    L2_2(L3_2, L4_2)
  end
  L2_2 = A1_2
  L3_2 = "ok"
  L2_2(L3_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNUICallback
L4_1 = "ffa:ready"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = true
  L2_1 = L2_2
  L2_2 = A1_2
  L3_2 = "ok"
  L2_2(L3_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNUICallback
L4_1 = "ffa:create"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = Exit
  L2_2()
  L2_2 = TriggerServerEvent
  L3_2 = "b-ffa:createFFA"
  L4_2 = A0_2.data
  L2_2(L3_2, L4_2)
  L2_2 = A1_2
  L3_2 = "ok"
  L2_2(L3_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterCommand
L4_1 = "quitffa"
function L5_1()
  local L0_2, L1_2
  L0_2 = IsPedDeadOrDying
  L1_2 = PlayerPedId
  L1_2 = L1_2()
  L0_2 = L0_2(L1_2)
  if L0_2 then
    return
  end
  L0_2 = TriggerServerEvent
  L1_2 = "b-ffa:quitFFA"
  L0_2(L1_2)
end
L3_1(L4_1, L5_1)
function L3_1(A0_2)
  local L1_2, L2_2
  while true do
    L1_2 = LocalPlayer
    L1_2 = L1_2.state
    L1_2 = L1_2.ffaEntered
    if L1_2 then
      break
    end
    L1_2 = Wait
    L2_2 = 0
    L1_2(L2_2)
  end
  L1_2 = Citizen
  L1_2 = L1_2.CreateThread
  function L2_2()
    local L0_3, L1_3, L2_3, L3_3
    L0_3 = vector3
    L1_3 = A0_2.position
    L1_3 = L1_3.x
    L2_3 = A0_2.position
    L2_3 = L2_3.y
    L3_3 = A0_2.position
    L3_3 = L3_3.z
    L0_3 = L0_3(L1_3, L2_3, L3_3)
    while true do
      L1_3 = LocalPlayer
      L1_3 = L1_3.state
      L1_3 = L1_3.ffaEntered
      if not L1_3 then
        break
      end
      L1_3 = L1_1
      if L1_3 then
        L1_3 = L1_3.sphere
      end
      if L1_3 then
        L1_3 = L1_3.enabled
      end
      if nil == L1_3 then
        break
      end
      L1_3 = Wait
      L2_3 = 500
      L1_3(L2_3)
      L1_3 = GetEntityCoords
      L2_3 = PlayerPedId
      L2_3, L3_3 = L2_3()
      L1_3 = L1_3(L2_3, L3_3)
      L1_3 = L1_3 - L0_3
      L1_3 = #L1_3
      L2_3 = A0_2.size
      if L1_3 > L2_3 then
        L2_3 = TriggerServerEvent
        L3_3 = "b-ffa:quitFFA"
        L2_3(L3_3)
        break
      end
    end
  end
  L1_2(L2_2)
  L1_2 = Citizen
  L1_2 = L1_2.CreateThread
  function L2_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L0_3 = vector3
    L1_3 = A0_2.position
    L1_3 = L1_3.x
    L2_3 = A0_2.position
    L2_3 = L2_3.y
    L3_3 = A0_2.position
    L3_3 = L3_3.z
    L0_3 = L0_3(L1_3, L2_3, L3_3)
    while true do
      L1_3 = LocalPlayer
      L1_3 = L1_3.state
      L1_3 = L1_3.ffaEntered
      if not L1_3 then
        break
      end
      L1_3 = L1_1
      if L1_3 then
        L1_3 = L1_3.sphere
      end
      if L1_3 then
        L1_3 = L1_3.enabled
      end
      if nil == L1_3 then
        break
      end
      L1_3 = Wait
      L2_3 = 0
      L1_3(L2_3)
      L1_3 = DrawSphere
      L2_3 = A0_2
      if L2_3 then
        L2_3 = L2_3.position
      end
      L2_3 = L2_3.x
      L3_3 = A0_2
      if L3_3 then
        L3_3 = L3_3.position
      end
      L3_3 = L3_3.y
      L4_3 = A0_2
      if L4_3 then
        L4_3 = L4_3.position
      end
      L4_3 = L4_3.z
      L5_3 = A0_2
      if L5_3 then
        L5_3 = L5_3.size
      end
      L6_3 = L1_1.sphere
      L6_3 = L6_3.color
      L6_3 = L6_3.r
      L7_3 = L1_1.sphere
      L7_3 = L7_3.color
      L7_3 = L7_3.g
      L8_3 = L1_1.sphere
      L8_3 = L8_3.color
      L8_3 = L8_3.b
      L9_3 = L1_1.sphere
      L9_3 = L9_3.alpha
      L1_3(L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
    end
  end
  L1_2(L2_2)
end
RenderSphere = L3_1
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = A0_2.spawnPoints
  L2_2 = math
  L2_2 = L2_2.random
  L3_2 = 1
  L4_2 = #L1_2
  L2_2 = L2_2(L3_2, L4_2)
  L2_2 = L1_2[L2_2]
  if not L2_2 then
    L3_2 = print
    L4_2 = "No spawnpoint found"
    return L3_2(L4_2)
  end
  L3_2 = TriggerEvent
  L4_2 = B_SERVICE
  L4_2 = L4_2.ReviveTrigger
  L3_2(L4_2)
  L3_2 = Wait
  L4_2 = 1000
  L3_2(L4_2)
  L3_2 = SetEntityCoords
  L4_2 = PlayerPedId
  L4_2 = L4_2()
  L5_2 = L2_2.x
  L6_2 = L2_2.y
  L7_2 = L2_2.z
  L3_2(L4_2, L5_2, L6_2, L7_2)
end
spawnToRandomSpawnPoint = L3_1
