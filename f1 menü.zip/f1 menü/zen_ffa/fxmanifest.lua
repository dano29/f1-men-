fx_version 'cerulean'
game 'gta5'

author 'Louis#2222'
description 'FiveM ESX FFA Script with Custom Lobbys'
version '1.0.0'

client_script {
   'config/clientconfig.lua',
   'client/*.lua',
}

server_script {
   '@mysql-async/lib/MySQL.lua',
   'config/clientconfig.lua',
   'config/serverconfig.lua',
   'server/classes/zone.lua',
   'server/classes/player.lua',
   'server/server.lua',
}

escrow_ignore {
   'config/clientconfig.lua',
   'config/serverconfig.lua',
}

ui_page {
   "html/dist/index.html"
   --"http://localhost:8080"
}

files {
   "html/dist/index.html",
   "html/dist/**.*"
}

lua54 'yes'

dependency '/assetpacks'