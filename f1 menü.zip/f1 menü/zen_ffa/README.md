# b-ffa API

Die b-ffa API ermöglicht den Zugriff auf die State Bags in FiveM. Diese State Bags speichern Informationen über Spieler und ihre Interaktionen im FFA-Modus auf b-service.xyz. Die folgenden Keys können verwendet werden, um auf spezifische Daten zuzugreifen:

- `ffaEntered`: Gibt an, ob der Spieler dem FFA-Modus beigetreten ist.
- `ffaEnteredCoords`: Die Koordinaten, an denen der Spieler dem FFA-Modus beigetreten ist.
- `ffaZoneId`: Die ID der Zone, in der sich der Spieler befindet.
- `ffaDeaths`: Die Anzahl der Tode des Spielers im FFA-Modus.
- `ffaKills`: Die Anzahl der Abschüsse (Kills) des Spielers im FFA-Modus.

## Rückgabewerte

Die API liefert keine direkten Rückgabewerte. Stattdessen können die oben genannten Keys verwendet werden, um die entsprechenden Informationen aus den State Bags abzurufen. Die Werte können dann weiterverwendet oder angezeigt werden, wie es für deine Anwendung erforderlich ist.

Beispielhaft könnte man folgenden Code verwenden, um die Werte abzurufen:

Serverside:
```lua
local ffaEntered = Player(source).state["ffaEntered"]
local ffaEnteredCoords = Player(source).state["ffaEnteredCoords"]
local ffaZoneId = Player(source).state["ffaZoneId"]
local ffaDeaths = Player(source).state["ffaDeaths"]
local ffaKills = Player(source).state["ffaKills"]
```

Clientside:
```lua
local ffaEntered = LocalPlayer.state["ffaEntered"]
local ffaEnteredCoords = LocalPlayer.state["ffaEnteredCoords"]
local ffaZoneId = LocalPlayer.state["ffaZoneId"]
local ffaDeaths = LocalPlayer.state["ffaDeaths"]
local ffaKills = LocalPlayer.state["ffaKills"]
```

## b-deathscreen Integration

`config/clientconfig.lua`

```lua
B_SERVICE.CanTriggerDeathEvent = function() -- Hier kann man z.B. exports von FFA hinzufügen um das Triggern des Death Events zu verhindern.
    if LocalPlayer.state["ffaEntered"] then -- z.B. Abfrage ob er in der FFA Zone ist. Wenn ja => geben wir False zurück und das Event wird NICHT getriggert.
         return false 
    end

    return true
end
```

## esx_ambulancejob Integration

- `client/main.lua`
- Suche nach "esx:onPlayerDeath" und ersetze es mit folgendem Code:

```lua
AddEventHandler('esx:onPlayerDeath', function(data)
  if LocalPlayer.state["ffaEntered"] then -- z.B. Abfrage ob er in der FFA Zone ist. Wenn ja => geben wir False zurück und das Event wird NICHT getriggert.
    return 
  end 

  OnPlayerDeath()
end)
```

Bitte beachte, dass diese Werte von Spielern individuell gespeichert und verwaltet werden. Daher kann jeder Spieler seine eigenen Werte haben, die unabhängig von anderen Spielern sind.

Bei weiteren Fragen oder Problemen wende dich bitte an das b-service.xyz-Supportteam.
