Config = {}

Config.Safezones = {
    { -- SCHWARZMARKT
        position = vector3(1395.6469, 3611.5176, 34.9809),
        radius = 100.0
    },
}