local isInSafezone = false
local uiReady = false

CreateThread(function()
    while (not uiReady) do
        Wait(0)
    end

    while true do
        if (IsPlayerInSafezone() and not isInSafezone) then
            SendNUIMessage({
                event = "setUiVisibility",
                visible = true
            })

            local playerPed = PlayerPedId()

            SetCanAttackFriendly(playerPed, true, true)
            NetworkSetFriendlyFireOption(true)
            SetEntityInvincible(playerPed, false)
            SetPlayerInvincible(PlayerId(), false)
            SetPedCanRagdoll(playerPed, true)
            ClearPedBloodDamage(playerPed)
            ResetPedVisibleDamage(playerPed)
            ClearPedLastWeaponDamage(playerPed)
            SetEntityProofs(playerPed, false, false, false, false, false, false, false, false)
            SetEntityCanBeDamaged(playerPed, true)
            SetCurrentPedWeapon(playerPed, `WEAPON_UNARMED`, false)
            SetPedCanSwitchWeapon(playerPed, true)

            isInSafezone = true
        elseif (not IsPlayerInSafezone() and isInSafezone) then
            SendNUIMessage({
                event = "setUiVisibility",
                visible = false
            })

            local playerPed = PlayerPedId()

            SetCanAttackFriendly(playerPed, true, false)
            NetworkSetFriendlyFireOption(true)
            SetEntityInvincible(playerPed, false)
            SetPlayerInvincible(PlayerId(), false)
            SetPedCanRagdoll(playerPed, true)
            ClearPedBloodDamage(playerPed)
            ResetPedVisibleDamage(playerPed)
            ClearPedLastWeaponDamage(playerPed)
            SetEntityProofs(playerPed, false, false, false, false, false, false, false, false)
            SetEntityCanBeDamaged(playerPed, true)
            SetPedCanSwitchWeapon(playerPed, true)

            isInSafezone = false
        end

        Wait(3000)
    end
end)

function IsPlayerInSafezone()
    local playerCoords = GetEntityCoords(PlayerPedId())

    for _, value in pairs(Config.Safezones) do
        local distance = #(value.position - playerCoords)

        if (distance <= value.radius) then
            return true
        end
    end

    return false
end

RegisterNuiCallback("ready", function(_, cb)
    uiReady = true

    cb(true)
end)
