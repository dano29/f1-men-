window.addEventListener("load", () => {
    fetch(`https://${GetParentResourceName()}/ready`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json; charset=UTF-8",
        },
        body: JSON.stringify({}),
    });
});

window.addEventListener("message", (event) => {
    if (event.data.event == "setUiVisibility") {
        const element = document.getElementById("main");

        element.style.opacity = event.data.visible ? 1 : 0;
    }
});
